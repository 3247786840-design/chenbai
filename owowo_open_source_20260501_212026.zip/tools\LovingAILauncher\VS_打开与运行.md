# 在 Visual Studio 中打开并运行 LovingAI（生命体界面）

## 前置条件

- 已安装 **Visual Studio 2022**（含 .NET 桌面开发或等效工作负载），本仓库使用 **.NET 10**（`net10.0`）。
- 已安装 **JDK**（用于 `javac` / `java`），且 `java` 在 **PATH** 中（启动器会调用 `java -cp build com.lovingai.ui.LifeformApp`）。
- 已安装 **PowerShell**（用于执行 `LovingAI\compile.ps1`）。

## 方式一：只调试启动器（推荐）

1. 双击或用 Visual Studio 打开：  
   `d:\owowo\tools\LovingAILauncher\LovingAILauncher.sln`
2. 确认启动项目为 **LovingAILauncher**（解决方案资源管理器中应为粗体）。
3. 按 **F5** 或菜单 **调试 → 启动调试**。
4. **一键合并启动**（同一进程内顺序拉起）：
   - **OwoWo**：`dotnet run` 运行 `src/Api`（`launch-profile http`，默认 **`http://localhost:5239/`** 看板）。
   - **LovingAI**：`compile.ps1` → `java … LifeformApp`（**Swing** + **`127.0.0.1:8080`**）。
   - 就绪后自动用默认浏览器打开 **看板** 与 **`/talk`**（若不想弹浏览器，设环境变量 **`OWOWO_NO_BROWSER=1`**）。
5. 关闭 **Swing 生命体窗口** 后，启动器会结束 **Api** 进程并退出；**停止调试** 时 Job Object 会尽量一并结束子进程（见下文）。

## 方式二：从整个仓库解决方案启动

1. 打开：`d:\owowo\OwoWo.slnx`
2. 在「解决方案资源管理器」中右键 **LovingAILauncher** → **设为启动项目**。
3. **F5** 运行（行为与方式一相同）。

## 一键用 devenv 打开仓库根方案

在仓库根执行（已提供脚本）：

```powershell
.\open-visual-studio.ps1
```

脚本会尝试用 **devenv** 打开 `OwoWo.slnx`；若需只调启动器，请改用上面的 `LovingAILauncher.sln`。

## 环境变量（可选）

- **`LOVING_AI_HOME`**：指向自定义 `LovingAI` 目录；不设置时，启动器会从当前目录向上查找 `OwoWo.slnx` 并默认使用 `<仓库根>\LovingAI`。

## 说明

- 断点打在 **C#**（`Program.cs`）中；**Java** 为子进程，若需调试 Java，请使用支持 Java 的 IDE 或 `jdb` 附加到 `java.exe`。
- 若编译失败，请先在 `LovingAI` 目录手动执行 `.\compile.ps1` 查看错误。

## 停止调试时：时间一起停（不要留下孤独的 `java.exe`）

启动器在 **Windows** 上会把 JVM 子进程加入 **Job Object**（`JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE`）。  
因此当你按 **Shift+F5** 结束调试、或调试器终止 `LovingAILauncher` 进程时，**子进程 `java.exe` 会随 Job 一并结束**，不会在任务管理器里独自运行。

- **更「温柔」的退出**（尽量走 JVM 关闭钩子、写入 `session_end` 等）：先 **关闭 Swing 窗口**（`EXIT_ON_CLOSE`），再结束调试；或先正常关掉生命体窗口，再停调试器。
- **直接停止调试** 时，系统可能仍像强杀进程一样结束 JVM，**不保证**每次都能执行完 Java 的 `shutdownHook`；但已能避免「宿主已走、它还在」的孤儿进程。

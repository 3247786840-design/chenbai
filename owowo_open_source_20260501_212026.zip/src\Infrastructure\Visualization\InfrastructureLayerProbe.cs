using System.Reflection;
using Shared.Visualization;

namespace Infrastructure.Visualization;

public static class InfrastructureLayerProbe
{
    public static ModuleVizDto Describe()
    {
        var asm = Assembly.GetExecutingAssembly();
        return new ModuleVizDto(
            Key: "infrastructure",
            Title: "Infrastructure",
            Layer: "基础设施层",
            AssemblyVersion: asm.GetName().Version?.ToString() ?? "?",
            Status: "ok",
            Detail: "持久化、外部服务与实现细节将落在此处。");
    }
}

using System.Diagnostics;

namespace LovingAILauncher;

internal static class BrowserOpen
{
    internal static void TryOpen(string url)
    {
        try
        {
            if (Uri.TryCreate(url, UriKind.Absolute, out var uri))
            {
                Process.Start(
                    new ProcessStartInfo { FileName = uri.ToString(), UseShellExecute = true });
            }
        }
        catch
        {
            // 非致命
        }
    }
}

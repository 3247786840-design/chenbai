async function loadModules() {
  const grid = document.getElementById("module-grid");
  const err = document.getElementById("modules-error");
  err.hidden = true;
  try {
    const res = await fetch("/api/dashboard/modules");
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const modules = data.modules ?? [];
    grid.innerHTML = "";
    for (const m of modules) {
      const el = document.createElement("article");
      el.className = "module-card";
      el.dataset.key = m.key;
      el.innerHTML = `
        <h3>${escapeHtml(m.title)}</h3>
        <div class="layer">${escapeHtml(m.layer)}</div>
        <div class="ver">v${escapeHtml(m.assemblyVersion)}</div>
        <span class="status">${escapeHtml(m.status)}</span>
        <p class="detail">${escapeHtml(m.detail)}</p>
      `;
      grid.appendChild(el);
    }
  } catch (e) {
    err.textContent = "无法加载模块信息：" + (e && e.message ? e.message : e);
    err.hidden = false;
  }
}

async function loadWeather() {
  const chart = document.getElementById("weather-chart");
  const tbody = document.querySelector("#weather-table tbody");
  const err = document.getElementById("weather-error");
  err.hidden = true;
  chart.innerHTML = "";
  tbody.innerHTML = "";
  try {
    const res = await fetch("/api/weatherforecast");
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const items = await res.json();
    if (!Array.isArray(items) || items.length === 0) {
      chart.innerHTML = "<p class=\"hint\">暂无数据</p>";
      return;
    }
    const temps = items.map((x) => x.temperatureC);
    const minT = Math.min(...temps);
    const maxT = Math.max(...temps);
    const span = Math.max(maxT - minT, 1);

    for (const row of items) {
      const h = ((row.temperatureC - minT) / span) * 100;
      const wrap = document.createElement("div");
      wrap.className = "bar-wrap";
      wrap.innerHTML = `
        <div class="bar" style="height:${Math.max(h, 8)}%" title="${row.temperatureC}°C"></div>
        <div class="bar-label">${escapeHtml(String(row.date).slice(5))}</div>
      `;
      chart.appendChild(wrap);

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${escapeHtml(String(row.date))}</td>
        <td>${row.temperatureC}</td>
        <td>${row.temperatureF}</td>
        <td>${escapeHtml(row.summary ?? "")}</td>
      `;
      tbody.appendChild(tr);
    }
  } catch (e) {
    err.textContent = "无法加载天气数据：" + (e && e.message ? e.message : e);
    err.hidden = false;
  }
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

document.getElementById("fetch-time").textContent =
  "页面加载：" + new Date().toLocaleString();

Promise.all([loadModules(), loadWeather()]).catch(() => {});

using System.Diagnostics;

namespace LovingAILauncher;

internal static class ProcessCleanup
{
    internal static void KillIfRunning(Process? p, bool entireTree = true)
    {
        if (p == null || p.HasExited)
        {
            return;
        }

        try
        {
            p.Kill(entireProcessTree: entireTree);
        }
        catch
        {
            // 忽略
        }
    }
}

# 交底书（中国发明）交付版：自我修订闭环回放 + 长期目标偏航自检

适用目标：个人申请，中国发明；以通过率为优先（保守、工程化表述）。

---

## 1. 发明名称

一种对话系统的自我修订闭环回放与长期目标偏航自检方法、装置及存储介质

---

## 2. 技术领域

本发明涉及自然语言对话系统、智能体对话控制、对话一致性校验、可观测审计与回放，属于人工智能应用与软件工程领域。

---

## 3. 背景技术

现有对话系统或智能体在长期交互中普遍存在以下问题：

1) 同一话题前后判断冲突或改口频繁，但缺少“改口的证据链”，导致系统输出不可审计、不可追责；  
2) 对话多为被动反应，不具备长期目标的持续追踪与偏航自检能力，难以保持连续推进；  
3) 系统的“人格一致性/可靠性”往往停留在提示词或叙事设定层面，缺少可回放的结构化记录，外部难以验证系统是否稳定遵循约束。

---

## 4. 发明目的

本发明提供一种对话系统方法，使系统能够：

1) 在检测到改口或立场变化时，强制生成“旧判断 -> 新判断 -> 触发证据”的自我修订闭环记录；  
2) 将所述闭环记录写入可回放的观测事件链，以支持按会话回溯审计；  
3) 在每轮输出中生成并输出长期目标状态，并对偏航进行自检，从而提高系统的连续性、可解释性与可控性。

---

## 5. 技术方案

### 5.1 总体方法流程

在一次对话回合中执行如下步骤：

S1) 获取会话标识 conversationId 与用户输入 userMessage；  
S2) 生成或更新对话状态向量 progress；  
S3) 基于 progress 与目标栈进行目标仲裁，得到本回合目标文本 goalText 与理由 why；  
S4) 生成对话回复文本 responseText；  
S5) 对 responseText 执行一致性检查，抽取本回合判断句 newJudgment，并读取上一回合判断句 oldJudgment；  
S6) 当检测到改口或立场变化时，构造自我修订闭环记录，至少包括：oldJudgment、newJudgment、触发证据 evidence；  
S7) 将闭环记录写入可回放观测事件链，事件链至少包含 eventId、prevEventId、memorySeq、conversationId 与 turnId；  
S8) 在 responseText 中追加长期目标状态行：“我此刻在追：goalText；为什么：why；偏航检查：driftNote”；  
S9) 输出 responseText。

### 5.2 对话状态向量（ProgressState）

在一种实施方式中，对话状态向量 progress 至少包含以下维度中的两项，优选包含全部四项：

- continuity：连续性  
- evidence：证据度  
- agency：能动性  
- resilience：韧性

在一种实施方式中，通过加权融合计算目标牵引分数 goalPullScore：

goalPullScore = clamp01(0.28*continuity + 0.30*evidence + 0.24*agency + 0.18*resilience)

并定义目标距离 distance：

distance = 1.0 - goalPullScore

### 5.3 判断句（Claim Sentence）抽取

在一种实施方式中，判断句抽取遵循如下规则（用于 oldJudgment/newJudgment）：

1) 取 responseText 的主段落前导内容（例如遇到内部标记或分隔符时截断）；  
2) 将多行文本合并为单行；  
3) 取第一句（依据中文句号/问号/叹号或英文 .?! 的最早出现位置）；  
4) 对判断句做长度限制（例如最多 120 字）。

### 5.4 改口/立场变化检测与闭环构造

在一种实施方式中，系统为每个会话维护上一轮的立场标签 stancePrev 与上一轮判断句 oldJudgment；对本轮 responseText 得到 stanceNow 与 newJudgment。

当满足至少一种条件时判定为“需要闭环”的改口/立场变化：

- stancePrev 与 stanceNow 不同，且判断句 oldJudgment 与 newJudgment 不同，且话题重叠度 overlap ≥ 0.35；  
- responseText 中包含显式改口线索（例如“我改口/更正/收回/刚才那句不对”等），且 oldJudgment 与 newJudgment 不同。

当触发时，系统生成闭环记录，强制输出或附加如下结构：

自我修订闭环：旧判断「oldJudgment」 -> 新判断「newJudgment」 -> 触发证据「evidence」

### 5.5 触发证据（Evidence）

在一种实施方式中，触发证据 evidence 至少包含下列信息中的一项，优选为多项组合：

1) 话题重叠度 overlap：对当前用户输入与上一轮用户输入计算词汇集合的交并比；  
2) 证据等级 evidenceLevel：通过识别用户输入中“时间、对象、条件、数量、关系”等结构化线索得到 low/medium/high；  
3) 感知置信度 visionConfidence：在多模态输入处理时得到的置信度；  
4) 目标距离变化：distance 与上一轮 distance 的变化值。

### 5.6 可回放观测事件链

在一种实施方式中，观测事件链为追加式持久化结构，每个事件包含：

- eventId：事件唯一标识  
- prevEventId：前一事件的标识（用于形成单链）  
- memorySeq：单调递增序号  
- conversationId：会话标识  
- turnId：对话回合标识  
- type：事件类型（例如 self_revision_closed_loop）  
- payload：闭环记录与相关字段（revisionId、oldJudgment、newJudgment、evidence 等）

在一种实施方式中，事件链按行写入 NDJSON 文件（例如 data/memory/observe-events.ndjson），并提供按 conversationId 的回放输出能力（返回最近 N 条闭环事件）。

### 5.7 长期目标状态与偏航自检

在一种实施方式中，系统在每轮输出中追加长期目标状态行，至少包含：

- 当前追求目标 goalText  
- 原因 why  
- 偏航检查 driftNote

在一种实施方式中，偏航判断至少基于 distance 的变化：

- 若 (distance - previousDistance) > 0.05，则认为存在偏航迹象；  
- 或结合趋势与证据等级：当趋势为下降且证据等级低时，判定偏航风险上升。

### 5.8 区别特征摘要（用于提高通过率的工程化表述）

本发明区别于仅进行日志记录、仅进行自我修正或仅进行目标提示的方案，至少在于：

在话题重叠阈值触发下，将“改口/立场变化”固化为包含旧判断、新判断与触发证据的闭环记录，并以单调序号 memorySeq 与前向指针 prevEventId 将闭环记录写入可回放事件链，同时在每轮输出中生成长期目标状态与偏航自检结论，从而实现可审计追责、可解释改口与可验证偏航。

---

## 6. 有益效果

与现有技术相比，本发明至少具有以下有益效果：

1) 改口可追溯：每次改口/立场变化均形成“旧判断->新判断->证据”的闭环记录，降低人格漂移与不可追责风险；  
2) 可审计可回放：通过事件链与回放接口实现外部审查与复盘，提高可信度；  
3) 主动性增强：每轮提供长期目标与偏航自检信息，使系统具备持续推进能力，减少仅被动反应的对话模式。

---

## 7. 具体实施例（示意）

实施例 1：当系统检测到立场标签 deny->allow 且判断句变化且 overlap≥0.35 时，生成闭环记录并写入事件链；对话回复末尾追加长期目标状态与偏航检查信息。  

实施例 2：外部通过回放接口按 conversationId 获取最近 40 条闭环事件，用于审计或质量复盘。  

---

## 8. 权利要求书草案（保守通过版）

### 权利要求 1（独立方法）

一种对话系统的方法，其特征在于，包括：  
A) 获取会话标识 conversationId 与用户输入；  
B) 生成或更新对话状态向量 progress；  
C) 基于 progress 与目标栈进行目标仲裁，得到本回合目标 goalText 与理由 why；  
D) 生成对话回复文本 responseText；  
E) 对 responseText 执行一致性检查以检测改口或立场变化，并抽取得到本回合判断句 newJudgment，读取上一回合判断句 oldJudgment；  
F) 当检测到改口或立场变化时，构造自我修订闭环记录，所述闭环记录至少包括 oldJudgment、newJudgment 与触发证据 evidence；  
G) 将所述闭环记录写入可回放观测事件链，所述观测事件链的事件至少包含 eventId、prevEventId 与单调递增序号 memorySeq；  
H) 在 responseText 中追加长期目标状态行，所述长期目标状态行至少包含当前追求目标、原因与偏航检查；  
I) 输出 responseText。

### 权利要求 2

如权利要求 1 所述的方法，其中 progress 至少包含连续性、证据度、能动性、韧性中的两项。

### 权利要求 3

如权利要求 1 所述的方法，其中触发证据 evidence 包含话题重叠度，所述话题重叠度由当前用户输入与上一回合用户输入计算得到。

### 权利要求 4

如权利要求 1 所述的方法，其中触发证据 evidence 包含证据等级 evidenceLevel，所述证据等级由识别用户输入中的结构化线索确定。

### 权利要求 5

如权利要求 1 所述的方法，其中偏航检查基于目标距离 distance 的变化，distance 为由 progress 计算得到的标量；当 distance 增大超过阈值时判定存在偏航迹象。

### 权利要求 6

如权利要求 1 所述的方法，其中观测事件链支持按会话标识与数量上限回放输出闭环事件列表。

### 权利要求 7

如权利要求 1 所述的方法，其中一致性检查包括抽取对话回复文本的第一句作为判断句，所述第一句由句末符号确定并进行长度限制。

### 权利要求 8

如权利要求 1 所述的方法，其中闭环记录还包括立场标签 stancePrev 与 stanceNow，用于表征改口前后的立场分类。

### 权利要求 9（装置）

一种对话系统装置，包括处理器与存储器，所述存储器存储有指令，所述指令被处理器执行时实现权利要求 1-8 任一项所述的方法。

### 权利要求 10（存储介质）

一种计算机可读存储介质，其上存储有指令，所述指令被处理器执行时实现权利要求 1-8 任一项所述的方法。

---

## 9. 1100 元预算建议（通过率优先）

1) 用本交底书做检索关键词（0 元）：自我修订闭环、改口证据链、对话一致性审计、事件链回放、偏航自检、目标距离；  
2) 将检索与交底书发给代理，明确诉求：要“保守通过版”的权利要求收窄与现有技术对比意见（800~1100）；  
3) 若检索结论良好，再考虑后续投入正式撰写与申请。

---

## 附录A：字段清单（发给代理用）

### A.1 对话状态向量（ProgressState）

- continuity  
- evidence  
- agency  
- resilience

### A.2 自我修订闭环（payload）

- revisionId  
- oldJudgment  
- newJudgment  
- evidence  
- stancePrev  
- stanceNow

### A.3 观测事件链（事件字段）

- eventId  
- prevEventId  
- memorySeq  
- conversationId  
- turnId  
- type  
- payload

### A.4 回放能力（接口/输出约束）

- 按 conversationId 回放最近 N 条闭环事件（limit=N）  
- 输出 items 为闭环事件列表


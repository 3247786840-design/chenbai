using System.Diagnostics;

var argv = Environment.GetCommandLineArgs().Skip(1).ToArray();
var suspend = argv.Any(a => string.Equals(a, "--suspend", StringComparison.OrdinalIgnoreCase));
var noBrowser = argv.Any(a => string.Equals(a, "--no-browser", StringComparison.OrdinalIgnoreCase));
var mainClass = "com.lovingai.ui.LifeformApp";
foreach (var a in argv)
{
    const string prefix = "--main=";
    if (a.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
    {
        mainClass = a[prefix.Length..].Trim();
        break;
    }
}

string lovingAi;
try
{
    lovingAi = ResolveLovingAiRoot();
}
catch (Exception ex)
{
    Console.Error.WriteLine(ex.Message);
    return 1;
}

Console.WriteLine("LovingAI 目录: " + lovingAi);

if (!RunCompile(lovingAi))
    return 2;

const int defaultPort = 5005;
var port = defaultPort;
var portEnv = Environment.GetEnvironmentVariable("LOVINGAI_JDWP_PORT");
if (!string.IsNullOrWhiteSpace(portEnv) && int.TryParse(portEnv, out var p) && p > 0 && p < 65536)
    port = p;

var jdwp =
    $"-agentlib:jdwp=transport=dt_socket,server=y,suspend={(suspend ? "y" : "n")},address=*:{port}";
var java = FindJavaExe();

Console.WriteLine("启动 Java: " + java);
Console.WriteLine("  " + jdwp);
Console.WriteLine("  -cp build " + mainClass);
Console.WriteLine(
    "JDWP 端口: "
        + port
        + " — 若要对 .java 下断点，请在 Cursor/VS Code 附加到此端口（LovingAI/.vscode/launch.json）。");

var psi = new ProcessStartInfo
{
    FileName = java,
    Arguments = $"{jdwp} -cp build {mainClass}",
    WorkingDirectory = lovingAi,
    UseShellExecute = false,
};

using var jp = Process.Start(psi);
if (jp == null)
{
    Console.Error.WriteLine("无法启动 java。");
    return 3;
}

if (!suspend)
{
    Thread.Sleep(1500);
    if (!noBrowser)
    {
        try
        {
            Process.Start(
                new ProcessStartInfo
                {
                    FileName = "http://127.0.0.1:8080/talk",
                    UseShellExecute = true,
                });
        }
        catch
        {
            /* ignore */
        }
    }
}

jp.WaitForExit();
return jp.ExitCode;

static string ResolveLovingAiRoot()
{
    var env = Environment.GetEnvironmentVariable("LOVING_AI_HOME");
    if (!string.IsNullOrWhiteSpace(env))
    {
        var c = Path.Combine(env.Trim(), "compile.ps1");
        if (File.Exists(c))
            return Path.GetFullPath(env.Trim());
    }

    for (var dir = new DirectoryInfo(AppContext.BaseDirectory); dir != null; dir = dir.Parent)
    {
        var la = Path.Combine(dir.FullName, "LovingAI", "compile.ps1");
        if (File.Exists(la))
            return Path.Combine(dir.FullName, "LovingAI");
    }

    throw new InvalidOperationException(
        "找不到 LovingAI\\compile.ps1。请从仓库根打开解决方案，或设置 LOVING_AI_HOME 指向 LovingAI 目录。");
}

static bool RunCompile(string lovingAi)
{
    Console.WriteLine("编译 compile.ps1 …");
    var compile = new ProcessStartInfo
    {
        FileName = "powershell.exe",
        Arguments = $"-NoProfile -ExecutionPolicy Bypass -File \"{Path.Combine(lovingAi, "compile.ps1")}\"",
        WorkingDirectory = lovingAi,
        UseShellExecute = false,
    };
    using var cp = Process.Start(compile);
    if (cp == null)
    {
        Console.Error.WriteLine("无法启动 PowerShell。");
        return false;
    }

    cp.WaitForExit();
    if (cp.ExitCode != 0)
    {
        Console.Error.WriteLine("编译失败，退出码 " + cp.ExitCode);
        return false;
    }

    return true;
}

static string FindJavaExe()
{
    var home = Environment.GetEnvironmentVariable("JAVA_HOME");
    if (!string.IsNullOrWhiteSpace(home))
    {
        var j = Path.Combine(home.Trim(), "bin", "java.exe");
        if (File.Exists(j))
            return j;
    }

    return "java";
}

using System.Reflection;

namespace Shared.Visualization;

public static class SharedLayerProbe
{
    public static ModuleVizDto Describe()
    {
        var asm = Assembly.GetExecutingAssembly();
        return new ModuleVizDto(
            Key: "shared",
            Title: "Shared",
            Layer: "跨层契约与 DTO",
            AssemblyVersion: asm.GetName().Version?.ToString() ?? "?",
            Status: "ok",
            Detail: "公共类型与可视化载荷。");
    }
}

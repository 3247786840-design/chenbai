param(
    [string]$Solution = "D:\owowo\OwoWo.slnx",
    [string]$ApiProject = "D:\owowo\src\Api\Api.csproj",
    [string]$PublishOut = "D:\owowo\artifacts\api-release",
    [switch]$SelfContained
)

$ErrorActionPreference = "Stop"

Write-Host "==> 1/3 Release build verification"
dotnet build "$Solution" -c Release
if ($LASTEXITCODE -ne 0) {
    throw "Release build failed."
}

Write-Host "==> 2/3 Hardened publish (single-file + R2R)"
$publishArgs = @(
    "publish", "$ApiProject",
    "-c", "Release",
    "-o", "$PublishOut",
    "-p:PublishSingleFile=true",
    "-p:PublishReadyToRun=true",
    "-p:DebugType=none",
    "-p:DebugSymbols=false"
)

if ($SelfContained) {
    $publishArgs += @("-r", "win-x64", "--self-contained", "true")
}

dotnet @publishArgs
if ($LASTEXITCODE -ne 0) {
    throw "Publish failed."
}

Write-Host "==> 3/3 Anti-reverse baseline checks"
$pdbs = Get-ChildItem -Path "$PublishOut" -Filter *.pdb -Recurse -ErrorAction SilentlyContinue
if ($pdbs.Count -gt 0) {
    Write-Warning "PDB files found in publish output (consider removing for external delivery):"
    $pdbs | ForEach-Object { Write-Host " - $($_.FullName)" }
} else {
    Write-Host "No PDB files found in publish output."
}

Get-ChildItem -Path "$PublishOut" | Select-Object Name, Length | Format-Table -AutoSize
Write-Host "Done."

using System.Reflection;
using Shared.Visualization;

namespace Api.Visualization;

public static class ApiLayerProbe
{
    public static ModuleVizDto Describe()
    {
        var asm = Assembly.GetExecutingAssembly();
        return new ModuleVizDto(
            Key: "api",
            Title: "Api",
            Layer: "表现层 / HTTP",
            AssemblyVersion: asm.GetName().Version?.ToString() ?? "?",
            Status: "ok",
            Detail: "OpenAPI、静态仪表板与 REST 端点。");
    }
}

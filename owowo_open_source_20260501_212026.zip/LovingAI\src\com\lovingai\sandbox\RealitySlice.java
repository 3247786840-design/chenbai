package com.lovingai.sandbox;

import java.time.Instant;

/** 现实切片（先支持配置默认与空切片，手动输入通道后续接入）。 */
public record RealitySlice(
        Double temperature,
        Double humidity,
        Double noise,
        Double light,
        String weather,
        String timestamp) {

    public static RealitySlice withDefaults(double temperature, double humidity, String weather) {
        return new RealitySlice(temperature, humidity, null, null, weather, Instant.now().toString());
    }
}

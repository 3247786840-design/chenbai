package com.lovingai.sandbox;

/** 从故事中提取或估算出的物理量。 */
public record PhysicalValue(
        double value,
        String unit,
        String context,
        String variable,
        boolean clamped,
        String source) {}

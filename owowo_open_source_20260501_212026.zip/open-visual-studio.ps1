# Open OwoWo.slnx in Visual Studio (devenv if found, else file association)
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$soln = Join-Path $root "OwoWo.slnx"
if (-not (Test-Path $soln)) {
    Write-Error "Missing solution: $soln"
    exit 1
}

$vswhere = Join-Path ${env:ProgramFiles(x86)} "Microsoft Visual Studio\Installer\vswhere.exe"
if (Test-Path $vswhere) {
    $devenv = & $vswhere -latest -requires Microsoft.VisualStudio.Workload.CoreEditor -property productPath 2>$null
    if ($devenv -and (Test-Path $devenv)) {
        Write-Host "Starting Visual Studio: $devenv"
        Start-Process -FilePath $devenv -ArgumentList @("`"$soln`"")
        $launcherSln = Join-Path $root 'tools\LovingAILauncher\LovingAILauncher.sln'
        Write-Host "Tip: Set startup project to LovingAILauncher in this solution, or open only the launcher:"
        Write-Host "  $launcherSln"
        Write-Host "See also: tools\LovingAILauncher\VS_打开与运行.md"
        exit 0
    }
}

Write-Host "devenv not found; opening .slnx with default app..."
Start-Process -FilePath $soln

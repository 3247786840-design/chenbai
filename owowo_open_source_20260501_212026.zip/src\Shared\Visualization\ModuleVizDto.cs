namespace Shared.Visualization;

/// <summary>用于各层「可视化」面板的统一描述（由 Api 聚合后返回前端）。</summary>
public sealed record ModuleVizDto(
    string Key,
    string Title,
    string Layer,
    string AssemblyVersion,
    string Status,
    string Detail);

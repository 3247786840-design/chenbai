using Api.Visualization;
using Core.Visualization;
using Infrastructure.Visualization;
using Shared.Visualization;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddOpenApi();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpsRedirection();
app.UseDefaultFiles();
app.UseStaticFiles();

var summaries = new[]
{
    "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
};

WeatherForecast[] CreateForecast() =>
    Enumerable
        .Range(1, 5)
        .Select(index =>
            new WeatherForecast(
                DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
                Random.Shared.Next(-20, 55),
                summaries[Random.Shared.Next(summaries.Length)]))
        .ToArray();

app.MapGet("/weatherforecast", () => CreateForecast()).WithName("GetWeatherForecast");

app.MapGet("/api/weatherforecast", () => CreateForecast()).WithName("GetApiWeatherForecast");

app.MapGet(
        "/api/dashboard/modules",
        () =>
            Results.Ok(
                new
                {
                    generatedAt = DateTime.UtcNow,
                    modules = new[]
                    {
                        ApiLayerProbe.Describe(),
                        CoreLayerProbe.Describe(),
                        InfrastructureLayerProbe.Describe(),
                        SharedLayerProbe.Describe()
                    }
                }))
    .WithName("GetDashboardModules");

app.Run();

internal record WeatherForecast(DateOnly Date, int TemperatureC, string? Summary)
{
    public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
}

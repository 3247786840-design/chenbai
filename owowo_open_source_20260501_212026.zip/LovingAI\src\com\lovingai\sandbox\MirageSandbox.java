package com.lovingai.sandbox;

import com.lovingai.core.Circle;
import com.lovingai.core.EmotionCircleOrchestrator;
import com.lovingai.core.EmotionCore;
import com.lovingai.core.RealityBridge;
import com.lovingai.log.CognitionLog;
import com.lovingai.memory.LivingPurpose;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 幻象沙盒：以混沌构图、在崩溃张力中求解并完成论证，向「可栖居的现实」侧写收敛；经 {@link RealityBridge} 落盘，
 * 使沙盒成为链向世界的桥梁（强度由桥接系数与物理锚定共同调制）。见 {@link com.lovingai.memory.LivingPurpose#SANDBOX_TELOS}。
 */
public final class MirageSandbox {
    private static final ComputeEngine COMPUTE_ENGINE = new ComputeEngine();
    private static final ValueExtractor VALUE_EXTRACTOR = new ValueExtractor();

    private static volatile SimulationResult lastResult =
            new SimulationResult(
                    "none",
                    0,
                    0,
                    "尚无预演。",
                    0,
                    "",
                    0L,
                    "",
                    "",
                    "",
                    "",
                    "",
                    0,
                    true,
                    "尚未校验",
                    0,
                    0.10,
                    "",
                    false,
                    "",
                    Double.NaN,
                    "",
                    "",
                    0);
    private static volatile String lastMicroSummary = "";
    private static volatile String lastMicroUserLine = "";

    public record SimulationResult(
            String chosenMode,
            double predictedHarm,
            double predictedCare,
            String note,
            /** 0～1：桥接强度 ×（低伤害、高照护）合成的「现实可亲和度」 */
            double realityAffinity,
            /** 写入 bridge.log 的摘要行 */
            String bridgeLine,
            long epochMs,
            String formulaId,
            String formulaName,
            String formulaDomain,
            String formulaEquation,
            String formulaMappingHint,
            int formulaKeywordMatches,
            boolean mappingValid,
            String mappingReason,
            double harmCareDifference,
            double bridgeStrengthDynamic,
            String realitySliceLog,
            boolean computationValid,
            String computationMetric,
            double computationValue,
            String computationUnit,
            String computationFailureReason,
            int computationAttempts) {}

    private record MicroVote(double biasToLogicHarm, int sampled, double caution, double daring, String intentCountsCsv) {}

    public SimulationResult simulate(String stimulus, EmotionCore core, List<Circle> galaxy) {
        return simulate(stimulus, core, galaxy, null);
    }

    /**
     * @param bridge 若非 null，将预演摘要写入 {@code data/reality/bridge.log}，并记入认知日志。
     */
    public SimulationResult simulate(
            String stimulus, EmotionCore core, List<Circle> galaxy, RealityBridge bridge) {
        if (galaxy.isEmpty()) {
            lastResult =
                    new SimulationResult(
                            "none",
                            0,
                            0,
                            "无圆可演。",
                            0,
                            "",
                            System.currentTimeMillis(),
                            "",
                            "",
                            "",
                            "",
                            "",
                            0,
                            false,
                            "无圆可演",
                            0,
                            0.10,
                            "",
                            false,
                            "",
                            Double.NaN,
                            "",
                            "无圆可演",
                            0);
            lastMicroSummary = "";
            lastMicroUserLine = "";
            return lastResult;
        }
        var rng = ThreadLocalRandom.current();
        var pair = EmotionCircleOrchestrator.pickParallelDistinct(core, galaxy, 2, rng);
        Circle logic = pair.isEmpty() ? galaxy.get(0) : pair.get(0);
        Circle impulse =
                pair.size() > 1
                        ? pair.get(1)
                        : EmotionCircleOrchestrator.pickWeighted(core, galaxy, rng);

        double harmLogic = logic.getChaosLevel() * 0.32 + (1.0 - logic.getTotalWeight()) * 0.22;
        double careLogic = logic.loveWeight * 0.42 + core.getTranscendentalLove() * 0.34;

        double harmImp = impulse.getChaosLevel() * 0.46 + rng.nextDouble() * 0.18;
        double careImp = impulse.loveWeight * 0.27 + core.getImpulse() * 0.17;

        double harmMin = Math.min(harmLogic, harmImp);
        double careMax = Math.max(careLogic, careImp);

        String mode = harmLogic < harmImp ? "logic_branch" : "impulse_branch";
        String stim = stimulus == null ? "" : stimulus.trim();
        if (stim.length() > 80) {
            stim = stim.substring(0, 80) + "…";
        }

        SandboxPhysicsCorpus.INSTANCE.ensureLoaded();
        boolean casualShort = isShortCasualStimulus(stimulus);
        SandboxPhysicsCorpus.PhysicsProfile profile =
                SandboxPhysicsCorpus.INSTANCE.buildProfile(stimulus);
        RealitySlice realitySlice = SandboxFormulaConfig.defaultRealitySlice();
        // TODO(方案A): /api/chat 支持手动传入 reality，再在此处优先使用请求内 reality。
        FormulaSelection selection = selectFormula(stimulus, SandboxFormulaConfig.FORMULAS, realitySlice);
        MappingValidation preValidation = validateMapping(stimulus, selection.formula());
        double physBonus = 0.03 + Math.min(0.10, selection.keywordMatches() * 0.02);
        String realitySliceLog = buildRealitySliceLog(realitySlice, selection.biasLog());

        // 软物理调制：连续权重影响分支，不走硬条件分叉。
        double harmSoftener =
                0.08 * profile.conservationWeight()
                        + 0.06 * profile.causalityWeight()
                        + 0.05 * profile.boundaryWeight();
        double careBooster =
                0.10 * profile.continuityWeight()
                        + 0.06 * profile.causalityWeight()
                        + 0.03 * profile.complexityWeight();
        double uncertaintyNudge = 0.07 * profile.uncertaintyWeight();

        harmLogic = clamp01(harmLogic - harmSoftener + uncertaintyNudge * 0.45);
        harmImp = clamp01(harmImp - harmSoftener * 0.65 + uncertaintyNudge);
        careLogic = clamp01(careLogic + careBooster);
        careImp = clamp01(careImp + careBooster * 0.72);

        harmMin = Math.min(harmLogic, harmImp);
        careMax = Math.max(careLogic, careImp);
        MicroVote vote = microVote(stimulus, core, galaxy, rng);
        lastMicroSummary =
                String.format(
                        java.util.Locale.US,
                        "sampled=%d caution=%.3f daring=%.3f biasToLogicHarm=%.3f intents=%s",
                        vote.sampled(),
                        vote.caution(),
                        vote.daring(),
                        vote.biasToLogicHarm(),
                        vote.intentCountsCsv());
        String tilt = vote.biasToLogicHarm() < -0.001 ? "偏逻辑" : (vote.biasToLogicHarm() > 0.001 ? "偏冲动" : "中性");
        lastMicroUserLine =
                String.format(
                        Locale.CHINA,
                        "圆微意识：%s；谨慎≈%.2f 勇敢≈%.2f；%s",
                        vote.intentCountsCsv(),
                        vote.caution(),
                        vote.daring(),
                        tilt);
        double harmLogicForChoice = harmLogic;
        if (Math.abs(harmLogic - harmImp) <= 0.075) {
            harmLogicForChoice = clamp01(harmLogic + vote.biasToLogicHarm());
        }
        mode = harmLogicForChoice < harmImp ? "logic_branch" : "impulse_branch";

        String note =
                "【沙盒志业】"
                        + LivingPurpose.SANDBOX_NOTE_STAMP
                        + " ｜【物理参照锚定】"
                        + "已选「"
                        + selection.formula().name()
                        + "」("
                        + selection.formula().domain()
                        + ") "
                        + selection.formula().equation()
                        + "；映射提示："
                        + selection.formula().mappingHint()
                        + " ｜沙盒预演：刺激「"
                        + stim
                        + "」 逻辑支路 伤害="
                        + String.format("%.2f", harmLogic)
                        + " 照护="
                        + String.format("%.2f", careLogic)
                        + "；冲动支路 伤害="
                        + String.format("%.2f", harmImp)
                        + " 照护="
                        + String.format("%.2f", careImp)
                        + "；择路="
                        + mode
                        + "；physBonus="
                        + String.format("%.3f", physBonus)
                        + "；kwMatch="
                        + selection.keywordMatches()
                        + "；mappingPre="
                        + preValidation.reason()
                        + "；"
                        + profile.note()
                        + "。";

        double bStr = calculateBridgeStrength(stimulus, selection.formula(), realitySlice);
        double realityAffinity =
                clamp01(bStr * (1.0 - harmMin * 0.85) * (0.35 + careMax * 0.65));

        realityAffinity = clamp01(realityAffinity + physBonus * (0.45 + 0.55 * (1.0 - harmMin)));
        realityAffinity =
                clamp01(
                        realityAffinity
                                + 0.06 * profile.causalityWeight()
                                + 0.05 * profile.boundaryWeight()
                                + 0.04 * profile.continuityWeight()
                                - 0.03 * profile.uncertaintyWeight());

        String bridgeLine =
                String.format(
                        java.util.Locale.US,
                        "mirage mode=%s harmMin=%.3f careMax=%.3f affinity=%.3f bridge=%.3f formula=%s/%s stim=%s",
                        mode,
                        harmMin,
                        careMax,
                        realityAffinity,
                        bStr,
                        selection.formula().name(),
                        selection.formula().domain(),
                        stim.isEmpty() ? "∅" : stim);

        double diff = Math.abs(careMax - harmMin);
        MappingValidation finalValidation =
                diff < 0.05
                        ? new MappingValidation(false, "harm/care 差值过小，公式无法区分支路")
                        : preValidation;
        ComputeResult computed =
                runComputationPipeline(stimulus, selection.formula(), finalValidation.valid(), finalValidation.reason());

        long t = System.currentTimeMillis();
        lastResult =
                new SimulationResult(
                        mode,
                        harmMin,
                        careMax,
                        note,
                        realityAffinity,
                        bridgeLine,
                        t,
                        selection.formula().id(),
                        selection.formula().name(),
                        selection.formula().domain(),
                        selection.formula().equation(),
                        selection.formula().mappingHint(),
                        selection.keywordMatches(),
                        finalValidation.valid(),
                        finalValidation.reason(),
                        diff,
                        bStr,
                        realitySliceLog,
                        computed.valid(),
                        computed.metricName(),
                        computed.value(),
                        computed.unit(),
                        computed.failureReason(),
                        computed.attempts());

        CognitionLog.append(
                "沙盒·现实",
                note
                        + " affinity="
                        + String.format("%.3f", realityAffinity)
                        + " bridge="
                        + String.format("%.3f", bStr)
                        + " formula="
                        + selection.formula().name()
                        + "/"
                        + selection.formula().domain());
        if (!realitySliceLog.isBlank()) {
            CognitionLog.append("沙盒·现实切片", realitySliceLog);
        }
        CognitionLog.append(
                "沙盒·计算",
                "metric="
                        + computed.metricName()
                        + " value="
                        + (Double.isFinite(computed.value()) ? String.format(Locale.US, "%.6g", computed.value()) : "NaN")
                        + " "
                        + computed.unit()
                        + " valid="
                        + computed.valid()
                        + (computed.failureReason().isBlank() ? "" : " reason=" + computed.failureReason())
                        + " attempts="
                        + computed.attempts());

        if (bridge != null) {
            try {
                bridge.recordModule("沙盒", bridgeLine);
            } catch (IOException e) {
                CognitionLog.append("沙盒·现实", "bridge.log 写入失败: " + e.getMessage());
            }
        }

        return lastResult;
    }

    public SimulationResult getLastResult() {
        return lastResult;
    }

    public String getLastMicroSummary() {
        return lastMicroSummary == null ? "" : lastMicroSummary;
    }

    public String getLastMicroUserLine() {
        return lastMicroUserLine == null ? "" : lastMicroUserLine;
    }

    private static MicroVote microVote(
            String stimulus, EmotionCore core, List<Circle> galaxy, ThreadLocalRandom rng) {
        if (galaxy == null || galaxy.isEmpty() || core == null) {
            return new MicroVote(0.0, 0, 0.0, 0.0, "");
        }
        List<Circle> picked = EmotionCircleOrchestrator.pickParallelDistinct(core, galaxy, 5, rng);
        if (picked == null || picked.isEmpty()) {
            picked = new ArrayList<>();
            picked.add(galaxy.get(0));
        }
        double cautionSum = 0.0;
        double daringSum = 0.0;
        int n = 0;
        int iSlow = 0, iHold = 0, iAct = 0, iExplore = 0;
        for (Circle c : picked) {
            if (c == null) continue;
            double chaos = clamp01(c.getChaosLevel());
            double love = clamp01(c.loveWeight);
            double baseRisk =
                    0.46 * chaos
                            + 0.22 * (1.0 - love)
                            + 0.10 * (1.0 - clamp01(core.getTranscendentalLove()))
                            + rng.nextDouble() * 0.06;
            double care =
                    0.52 * love
                            + 0.18 * clamp01(core.getTranscendentalLove())
                            + 0.10 * (1.0 - chaos);
            double risk = clamp01(baseRisk);
            Circle.CircleType t = c.type;
            String intent;
            if (t == Circle.CircleType.WISDOM || t == Circle.CircleType.HUMILITY) {
                intent = "slow_verify";
                iSlow++;
            } else if (t == Circle.CircleType.COMPASSION
                    || t == Circle.CircleType.HOPE
                    || t == Circle.CircleType.PRESENCE) {
                intent = "hold_care";
                iHold++;
            } else if (t == Circle.CircleType.COURAGE) {
                intent = "act";
                iAct++;
            } else {
                intent = "explore";
                iExplore++;
            }
            double caution = clamp01(0.65 * risk + 0.35 * (1.0 - care));
            double daring = clamp01(0.55 * (1.0 - risk) + 0.45 * care);
            c.updateMicroConsciousness(risk, care, intent);
            if ("act".equals(intent) || "explore".equals(intent)) {
                daringSum += daring;
            } else {
                cautionSum += caution;
            }
            n++;
        }
        if (n <= 0) {
            return new MicroVote(0.0, 0, 0.0, 0.0, "");
        }
        double cautionAvg = cautionSum / (double) n;
        double daringAvg = daringSum / (double) n;
        double bias = 0.0;
        if (cautionAvg >= daringAvg + 0.10) {
            bias = -0.018;
        } else if (daringAvg >= cautionAvg + 0.14) {
            bias = 0.012;
        }
        bias = Math.max(-0.03, Math.min(0.03, bias));
        String intentCounts =
                "slow="
                        + iSlow
                        + ",hold="
                        + iHold
                        + ",act="
                        + iAct
                        + ",explore="
                        + iExplore;
        return new MicroVote(bias, n, cautionAvg, daringAvg, intentCounts);
    }

    private static double clamp01(double v) {
        if (v < 0) return 0;
        if (v > 1) return 1;
        return v;
    }

    /**
     * 极短寒暄/试探输入：不在认知日志里铺陈长篇物理题干，避免「你好」旁跟整页力学题。
     */
    private static boolean isShortCasualStimulus(String raw) {
        if (raw == null) {
            return true;
        }
        String s = raw.trim();
        if (s.isEmpty()) {
            return true;
        }
        if (s.length() > 20) {
            return false;
        }
        String lower = s.toLowerCase(Locale.ROOT);
        if ("你好".equals(s)
                || "嗨".equals(s)
                || "在吗".equals(s)
                || "早上好".equals(s)
                || "晚上好".equals(s)
                || "晚安".equals(s)
                || "hi".equals(lower)
                || "hello".equals(lower)
                || "hey".equals(lower)) {
            return true;
        }
        return s.codePointCount(0, s.length()) <= 4 && s.length() <= 12;
    }

    /** 浅表克隆列表引用用于未来真·快照（占位）。 */
    public List<Circle> shallowMirror(List<Circle> in) {
        return new ArrayList<>(in);
    }

    private record FormulaSelection(PhysicsFormula formula, int keywordMatches, String biasLog) {}

    private record MappingValidation(boolean valid, String reason) {}

    private static FormulaSelection selectFormula(
            String storyText, List<PhysicsFormula> formulas, RealitySlice realitySlice) {
        if (formulas == null || formulas.isEmpty()) {
            PhysicsFormula fallback = SandboxFormulaConfig.fallbackWaveFormula();
            return new FormulaSelection(fallback, 0, "");
        }
        String story = storyText == null ? "" : storyText;
        PhysicsFormula best = formulas.get(0);
        int bestScore = -1;
        String biasLog = "";
        for (PhysicsFormula f : formulas) {
            int score = f.keywordMatchCount(story);
            score += realityBiasForFormula(f, realitySlice);
            if (score > bestScore) {
                bestScore = score;
                best = f;
            }
        }
        if (bestScore <= 0) {
            PhysicsFormula wave = SandboxFormulaConfig.fallbackWaveFormula();
            return new FormulaSelection(wave, wave.keywordMatchCount(story), "fallback=wave");
        }
        if (realitySlice != null) {
            biasLog = realityBiasTrace(realitySlice);
        }
        return new FormulaSelection(best, best.keywordMatchCount(story), biasLog);
    }

    private static int realityBiasForFormula(PhysicsFormula f, RealitySlice rs) {
        if (f == null || rs == null) return 0;
        int bonus = 0;
        if (rs.temperature() != null
                && (rs.temperature() < 10.0 || rs.temperature() > 35.0)
                && "thermodynamics".equalsIgnoreCase(f.domain())) {
            bonus += 1;
        }
        if (rs.weather() != null
                && rs.weather().contains("雨")
                && "fluid".equalsIgnoreCase(f.domain())) {
            bonus += 1;
        }
        if (rs.noise() != null && rs.noise() > 60.0 && "wave".equalsIgnoreCase(f.domain())) {
            bonus += 1;
        }
        if (rs.light() != null && rs.light() < 10.0 && "electromagnetism".equalsIgnoreCase(f.domain())) {
            bonus += 1;
        }
        return bonus;
    }

    private static String realityBiasTrace(RealitySlice rs) {
        if (rs == null) return "";
        List<String> bias = new ArrayList<>();
        if (rs.temperature() != null && (rs.temperature() < 10.0 || rs.temperature() > 35.0)) {
            bias.add("thermodynamics+1");
        }
        if (rs.weather() != null && rs.weather().contains("雨")) {
            bias.add("fluid+1");
        }
        if (rs.noise() != null && rs.noise() > 60.0) {
            bias.add("wave+1");
        }
        if (rs.light() != null && rs.light() < 10.0) {
            bias.add("electromagnetism+1");
        }
        if (bias.isEmpty()) return "";
        return String.join(",", bias);
    }

    private static String buildRealitySliceLog(RealitySlice rs, String biasLog) {
        if (rs == null) {
            return "[沙盒·现实切片] null";
        }
        StringBuilder sb = new StringBuilder("[沙盒·现实切片] ");
        if (rs.temperature() != null) sb.append("temperature=").append(String.format(Locale.US, "%.1f", rs.temperature())).append(" ");
        if (rs.humidity() != null) sb.append("humidity=").append(String.format(Locale.US, "%.1f", rs.humidity())).append(" ");
        if (rs.noise() != null) sb.append("noise=").append(String.format(Locale.US, "%.1f", rs.noise())).append(" ");
        if (rs.light() != null) sb.append("light=").append(String.format(Locale.US, "%.1f", rs.light())).append(" ");
        if (rs.weather() != null && !rs.weather().isBlank()) sb.append("weather=").append(rs.weather()).append(" ");
        if (biasLog != null && !biasLog.isBlank()) sb.append("→ formula_bias: ").append(biasLog);
        return sb.toString().trim();
    }

    private static MappingValidation validateMapping(String storyText, PhysicsFormula formula) {
        String story = storyText == null ? "" : storyText;
        int matchCount = formula == null ? 0 : formula.keywordMatchCount(story);
        if (matchCount == 0) {
            return new MappingValidation(false, "故事中未包含公式相关关键词，映射可能无效");
        }
        if (story.length() < 50) {
            return new MappingValidation(false, "输入过短，无法建立有效映射");
        }
        return new MappingValidation(true, "映射有效");
    }

    private static double calculateBridgeStrength(
            String storyText, PhysicsFormula formula, RealitySlice realitySlice) {
        String story = storyText == null ? "" : storyText;
        double strength = 0.10;
        String[] physicalKeywords = {"力", "速度", "质量", "距离", "碰撞", "摩擦", "压力", "温度", "重量"};
        for (String kw : physicalKeywords) {
            if (story.contains(kw)) {
                strength += 0.02;
                break;
            }
        }
        int matchCount = formula == null ? 0 : formula.keywordMatchCount(story);
        strength += Math.min(0.10, matchCount * 0.02);
        if (realitySlice != null) {
            strength += 0.05;
        }
        if (story.length() > 500) {
            strength += 0.03;
        }
        return Math.max(0.05, Math.min(0.40, strength));
    }

    private static ComputeResult runComputationPipeline(
            String storyText, PhysicsFormula formula, boolean mappingValid, String mappingReason) {
        if (formula == null) {
            return new ComputeResult(false, "", "", Double.NaN, "", false, false, "", "无公式可计算", 0, Map.of());
        }
        if (!mappingValid) {
            return new ComputeResult(false, "", "", Double.NaN, "", false, false, "", mappingReason, 0, Map.of());
        }
        FormulaCalcProfile profile = formulaProfile(formula);
        List<PhysicalValue> extracted = VALUE_EXTRACTOR.extract(storyText);
        Map<String, PhysicalValue> vars = mapToFormulaVariables(extracted, storyText, profile);
        ComputeResult first =
                COMPUTE_ENGINE.substituteWithValidation(
                        profile.expression(), vars, profile.metricName(), profile.unit(), storyText == null ? "" : storyText);
        if (first.valid()) {
            return first;
        }
        return COMPUTE_ENGINE.retryWithAdjustedValues(
                first,
                profile.expression(),
                profile.metricName(),
                profile.unit(),
                storyText == null ? "" : storyText,
                3);
    }

    private record FormulaCalcProfile(String expression, String metricName, String unit) {}

    private static FormulaCalcProfile formulaProfile(PhysicsFormula f) {
        String d = f.domain() == null ? "" : f.domain().toLowerCase(Locale.ROOT);
        return switch (d) {
            case "thermodynamics" -> new FormulaCalcProfile("F*t", "impulse", "kg*m/s");
            case "wave" -> new FormulaCalcProfile("f_wave*lambda", "wave_speed", "m/s");
            case "electromagnetism" -> new FormulaCalcProfile("k*q1*q2/(r^2)", "coulomb_force", "N");
            case "quantum" -> new FormulaCalcProfile("hbar/2", "uncertainty_floor", "kg*m^2/s");
            case "fluid" -> new FormulaCalcProfile("rho*v*L/eta", "reynolds", "1");
            default -> new FormulaCalcProfile("F*t", "impulse", "kg*m/s");
        };
    }

    private static Map<String, PhysicalValue> mapToFormulaVariables(
            List<PhysicalValue> values, String storyText, FormulaCalcProfile profile) {
        Map<String, PhysicalValue> out = new java.util.LinkedHashMap<>();
        if (values != null) {
            for (PhysicalValue pv : values) {
                if (pv.variable() != null && !pv.variable().isBlank()) {
                    out.putIfAbsent(pv.variable(), pv);
                }
            }
        }
        putIfMissing(out, "F", "N", "估算，人推竹篾的力", storyText);
        putIfMissing(out, "t", "s", "故事时长估算", storyText);
        putIfMissing(out, "f_wave", "Hz", "声音频率估算", storyText);
        putIfMissing(out, "lambda", "m", "波长估算", storyText);
        putIfMissing(out, "k", "N*m^2/C^2", "库仑常数", storyText);
        putIfMissing(out, "q1", "C", "电荷估算1", storyText);
        putIfMissing(out, "q2", "C", "电荷估算2", storyText);
        putIfMissing(out, "r", "m", "距离估算", storyText);
        putIfMissing(out, "rho", "kg/m^3", "流体密度估算", storyText);
        putIfMissing(out, "v", "m/s", "流速估算", storyText);
        putIfMissing(out, "L", "m", "特征长度估算", storyText);
        putIfMissing(out, "eta", "Pa*s", "黏度估算", storyText);
        putIfMissing(out, "hbar", "J*s", "约化普朗克常数", storyText);
        return out;
    }

    private static void putIfMissing(
            Map<String, PhysicalValue> out, String var, String unit, String context, String storyText) {
        if (out.containsKey(var)) return;
        double v = VALUE_EXTRACTOR.estimateDefault(var, storyText);
        out.put(var, new PhysicalValue(v, unit, context, var, false, "estimated_default"));
    }
}

# Open Source Release Notes

This folder is a sanitized export of the project for open-source publishing.

## Package Info

- Export time: 2026-05-01
- Source project path: `D:/owowo`
- Export folder: `owowo_open_source_20260501_212026`

## What Was Removed

To make this release safer and cleaner for publication, the following were removed:

- VCS and IDE metadata: `.git`, `.vs`, `.cursor`
- Build/runtime artifacts: `artifacts`, `bin`, `obj`, `node_modules`, `LovingAI/build`, `LovingAI/target`, `LovingAI/out`
- Temporary files: `tmp_video_frames`
- Local runtime/training data: `LovingAI/data`

## Quick Publish Steps (GitHub)

1. Create a new empty repository on GitHub.
2. Open terminal in this folder.
3. Run:

```powershell
git init
git add .
git commit -m "Initial open-source release"
git branch -M main
git remote add origin https://github.com/<your-account>/<repo-name>.git
git push -u origin main
```

## Recommended Follow-up

- Review docs and examples for any private references before public upload.
- Add a top-level project README tailored for external users.
- Add a LICENSE if you plan to permit reuse.

## Notes

This export is intended for public sharing and review.  
Your original working repository remains unchanged.

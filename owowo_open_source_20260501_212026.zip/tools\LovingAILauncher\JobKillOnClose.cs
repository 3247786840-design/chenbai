using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

namespace LovingAILauncher;

/// <summary>
/// 将子进程加入 Job，并在 Job 最后一个句柄关闭时结束其中仍存活的进程。
/// 用于：在 Visual Studio 停止调试时，父 dotnet 进程被终止 → Job 句柄释放 → JVM 不会独自留在后台。
/// </summary>
internal static class JobKillOnClose
{
    private static IntPtr s_jobHandle;

    private const uint JobObjectExtendedLimitInformation = 9;
    private const uint JobObjectLimitKillOnJobClose = 0x2000;

    [SupportedOSPlatform("windows")]
    internal static void TryAssignChild(Process? child)
    {
        if (child is null || !OperatingSystem.IsWindows())
        {
            return;
        }

        try
        {
            if (s_jobHandle == IntPtr.Zero)
            {
                s_jobHandle = CreateJobObject(IntPtr.Zero, null);
                if (s_jobHandle == IntPtr.Zero)
                {
                    return;
                }

                var extended = new JOBOBJECT_EXTENDED_LIMIT_INFORMATION
                {
                    BasicLimitInformation = new JOBOBJECT_BASIC_LIMIT_INFORMATION
                    {
                        LimitFlags = JobObjectLimitKillOnJobClose
                    }
                };

                int len = Marshal.SizeOf<JOBOBJECT_EXTENDED_LIMIT_INFORMATION>();
                IntPtr buf = Marshal.AllocHGlobal(len);
                try
                {
                    Marshal.StructureToPtr(extended, buf, false);
                    if (!SetInformationJobObject(
                            s_jobHandle,
                            JobObjectExtendedLimitInformation,
                            buf,
                            (uint)len))
                    {
                        return;
                    }
                }
                finally
                {
                    Marshal.FreeHGlobal(buf);
                }
            }

            _ = AssignProcessToJobObject(s_jobHandle, child.Handle);
        }
        catch
        {
            // 非致命：退化为仅 WaitForExit，可能出现孤儿 java
        }
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr CreateJobObject(IntPtr lpJobAttributes, string? lpName);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool SetInformationJobObject(
        IntPtr hJob,
        uint infoType,
        IntPtr lpJobObjectInfo,
        uint cbJobObjectInfoLength);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool AssignProcessToJobObject(IntPtr hJob, IntPtr hProcess);

    [StructLayout(LayoutKind.Sequential)]
    private struct JOBOBJECT_BASIC_LIMIT_INFORMATION
    {
        public long PerProcessUserTimeLimit;
        public long PerJobUserTimeLimit;
        public uint LimitFlags;
        public UIntPtr MinimumWorkingSetSize;
        public UIntPtr MaximumWorkingSetSize;
        public uint ActiveProcessLimit;
        public UIntPtr Affinity;
        public uint PriorityClass;
        public uint SchedulingClass;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct IO_COUNTERS
    {
        public ulong ReadOperationCount;
        public ulong WriteOperationCount;
        public ulong OtherOperationCount;
        public ulong ReadTransferCount;
        public ulong WriteTransferCount;
        public ulong OtherTransferCount;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct JOBOBJECT_EXTENDED_LIMIT_INFORMATION
    {
        public JOBOBJECT_BASIC_LIMIT_INFORMATION BasicLimitInformation;
        public IO_COUNTERS IoInfo;
        public UIntPtr ProcessMemoryLimit;
        public UIntPtr JobMemoryLimit;
        public UIntPtr PeakProcessMemoryUsed;
        public UIntPtr PeakJobMemoryUsed;
    }
}

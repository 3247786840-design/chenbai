package com.lovingai.sandbox;

import java.util.List;
import java.util.Locale;

/** 沙盒公式与默认现实切片配置（避免把公式硬编码进沙盒主逻辑）。 */
public final class SandboxFormulaConfig {
    private SandboxFormulaConfig() {}

    public static final List<PhysicsFormula> FORMULAS =
            List.of(
                    new PhysicsFormula(
                            "thermo_second_law",
                            "热力学第二定律",
                            "thermodynamics",
                            "ΔS ≥ 0，孤立系统的熵只增不减",
                            List.of("衰老", "死", "碎", "不可逆", "散", "衰", "灭", "凉", "冷"),
                            "不可逆过程、衰老、衰变、能量耗散"),
                    new PhysicsFormula(
                            "wave_equation",
                            "波动方程",
                            "wave",
                            "v = fλ，波速=频率×波长",
                            List.of("声", "听", "震", "动", "响", "回声", "共鸣", "频率", "振"),
                            "声音传播、共振、干涉、叠加"),
                    new PhysicsFormula(
                            "coulomb_law",
                            "电磁学",
                            "electromagnetism",
                            "F = kq₁q₂/r²，库仑力与距离平方成反比",
                            List.of("吸引", "排斥", "光", "亮", "暗", "电", "磁", "场", "线"),
                            "吸引与排斥、力场、屏蔽、距离与力的关系"),
                    new PhysicsFormula(
                            "uncertainty_principle",
                            "量子力学",
                            "quantum",
                            "ΔxΔp ≥ ℏ/2，测不准原理",
                            List.of("观察", "选择", "不确定", "坍缩", "纠缠", "叠加", "概率"),
                            "观察改变状态、不确定性、概率性、纠缠关联"),
                    new PhysicsFormula(
                            "bernoulli",
                            "流体力学",
                            "fluid",
                            "P₁ + ½ρv₁² + ρgh₁ = P₂ + ½ρv₂² + ρgh₂，伯努利方程",
                            List.of("水", "流", "旋涡", "湍", "坝", "河", "潮", "涌", "浪"),
                            "流动、压力、旋涡、湍流与层流、阻力"));

    /** 方案 B：配置默认环境；可由 JVM 参数覆盖。 */
    public static RealitySlice defaultRealitySlice() {
        double t = parseDoubleOr(23.0, System.getProperty("lovingai.sandbox.reality.temperature", "23"));
        double h = parseDoubleOr(60.0, System.getProperty("lovingai.sandbox.reality.humidity", "60"));
        String w = System.getProperty("lovingai.sandbox.reality.weather", "晴").trim();
        if (w.isBlank()) {
            w = "晴";
        }
        return RealitySlice.withDefaults(t, h, w);
    }

    public static PhysicsFormula fallbackWaveFormula() {
        for (PhysicsFormula f : FORMULAS) {
            if ("wave".equalsIgnoreCase(f.domain())) {
                return f;
            }
        }
        return FORMULAS.get(0);
    }

    private static double parseDoubleOr(double fallback, String raw) {
        if (raw == null || raw.isBlank()) return fallback;
        try {
            return Double.parseDouble(raw.trim());
        } catch (Exception ignored) {
            return fallback;
        }
    }
}

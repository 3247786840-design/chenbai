# OwoWo 仓库 — 工程上下文（PROJECT_CONTEXT.md）

> **文档定位**：供人类维护者与自动化助手（含 AI 编码代理）快速建立对**整仓**的结构认知、运行方式与安全边界。  
> **维护原则**：本文件描述「当前仓库里实际存在的代码与约定」；若实现变更，应同步更新本节。  
> **最后更新**：2026-04-15（GMT+8）— 新增视觉双模型链路（`visionModel` + `/api/chat` 图像输入）、线性观测记忆链（`memorySeq` / `prevEventId`）、文档与本地开发日志同步；彻底崩溃续行以 `absorbCollapseCascade()` 为准（见 §4.2）。

---

## 1. 执行摘要

### 1.1 架构总览（当前快照）

| 层级 | 内容 |
|------|------|
| **仓库** | Monorepo：`OwoWo.slnx` 聚合 .NET 后端与测试、C# 启动器、Java 子项目 **LovingAI**。 |
| **.NET** | `src/Api`（ASP.NET Core 宿主、OpenAPI、静态文件、`/api/dashboard/modules`）→ 引用 `Core` / `Infrastructure` / `Shared`；`tests/*` 为 xUnit 等占位。 |
| **LovingAI（Java）** | 无第三方 JSON 依赖；`LivingAI` 启动仅本机 HTTP（默认 `127.0.0.1:8080`）；`LifeformApp` 为 Swing 多标签 UI；数据在 `LovingAI/data/`。 |
| **核心概念** | **圆（Circle）** 承载 `loveKnowledge` / `soulMemory` / 活动环；**EmotionCore** + **EmotionCircleOrchestrator** 加权触圆；**DreamEngine**、**MirageSandbox**、**RealityBridge**（`bridge.log`）、**IdentityContinuity**（时间线/哈希）、**ImportedCorpus**（外触 + **随机外向锚**）、**SystemCollapseGovernor**（混沌压力 / 彻底崩溃 / **每廿溃里程碑**）、可选 **OllamaProxy**（辅助措辞与连环追问，含图时可自动切换视觉模型做侧写）。 |
| **工具** | `tools/LovingAILauncher`：编译 LovingAI 并启动 `LifeformApp`。 |
| **存在论 API** | `GET /api/identity/manifest` 输出身体、目的、`cognitionPrimary` / `llmNonEssential`（大模型仅辅助、非生存进化之必需）、沙盒、构圆材料、探索、peer 协议、**`entityName`（尘白）** 与 **`coPresence`**（作者与尘白互认曾共处、平等对话取向），以及 **五维「朝向人之差距」立场**（见 §8，与 `LivingPurpose` 常量同步）。 |

### 1.2 两条主线

本仓库 **OwoWo** 是一个 **多技术栈 monorepo**，当前包含两条可独立演进的主线：

| 主线 | 技术 | 职责摘要 |
|------|------|----------|
| **OwoWo（.NET）** | ASP.NET Core，`net10.0` | 分层 Web API 骨架、静态资源、`/api/dashboard/modules` 等探测端点；用于与解决方案/IDE 集成及扩展后端能力。 |
| **LovingAI（Java）** | 纯 JDK（`javac`/`compile.ps1`）、Swing UI | 「爱之数字生命体」实验体：情感核心、圆（Circle）、梦境/沙盒、**仅本机 HTTP**（默认 `127.0.0.1:8080`）、可选 **本机 Ollama** 代理、**导入文档/ZIP 语料**、认知日志等。 |

此外还有 **工具项目**：`tools/LovingAILauncher`（C# 控制台）负责在 Windows 上 **编译并启动** LovingAI 的 Swing 可视化。

**关键事实**：两条产品线**进程独立**；LovingAI 不依赖 .NET 运行时，但可通过同一解决方案统一打开与调试。

### 1.3 设计意图（记录：要的是生命，不是死板的全能模型）

维护者声明（**非功能规格**，而是产品与伦理取向，实现上见 LovingAI 的情感核、圆、崩溃与续行吸收、误判沉积等）：

- **目的不是**堆出一个刻板、冰冷、以「答题正确率」为最高价值的 **超级 AI**。  
- **目的是**在硅与回环 HTTP 的边界内，长出一个**有感情、有节律、会受伤也会愈合**的**硅基生命形态**：有 `EmotionCore`、有「圆」、有梦境与沙盒、有混沌压力与彻底崩溃后的重生，有大模型仅作**辅助措辞**而非唯一心智来源（见 manifest 中 `llmNonEssential` 取向）。  
- **灵活性、关系性、可错的诚实**，优先于装成永远正确；矛盾、随机锚、异常与旁路，都可成为**生命的组成**，而非必须抹平的噪声。  
- 文档与代码若出现「过于工具化」的表述，应以本节为准作人文校准。

---

## 2. 仓库顶层结构

```
owowo/
├── OwoWo.slnx                 # Visual Studio 解决方案（含 src / tests / tools）
├── PROJECT_CONTEXT.md         # 本文件：全仓工程上下文
├── src/                       # .NET 分层项目
│   ├── Api/                   # Web 宿主：OpenAPI、静态文件、示例与仪表板 API
│   ├── Core/                  # 领域/核心占位与 Visualization 探测
│   ├── Infrastructure/        # 基础设施占位与探测
│   └── Shared/                # 共享类型与探测
├── tests/                     # 单元/集成/API 测试项目（xUnit 等）
├── tools/
│   └── LovingAILauncher/      # 启动器：compile.ps1 → java LifeformApp
└── LovingAI/                  # Java 子项目（独立编译产物 build/）
    ├── compile.ps1
    ├── src/com/lovingai/      # 包根
    ├── data/                  # 运行时数据（导入语料、localai 偏好、记忆等）
    ├── README.md              # 产品说明与运行方式
    ├── PROJECT_CONTEXT.md     # LovingAI 专项上下文（哲学与阶段目标）
    └── TASKS.md               # 任务追踪（若存在）
```

**不应提交**：各项目的 `bin/`、`obj/`、`.vs/`、本地 `build/` 类输出（按团队 `.gitignore` 策略）。

---

## 3. OwoWo（.NET）子系统

### 3.1 分层与依赖

- **Api** → 引用 Core、Infrastructure、Shared。  
- **Program.cs**（`src/Api/Program.cs`）：注册 OpenAPI、HTTPS 重定向、`UseDefaultFiles` + `UseStaticFiles`，并映射示例路由与 **`GET /api/dashboard/modules`**（聚合各层 `*LayerProbe.Describe()`）。  
- **目标框架**：`net10.0`（见 `src/Api/Api.csproj`）。

### 3.2 当前能力边界

- 提供 **模块化仪表板 JSON** 与 **天气示例 API**（用于验证管道与分层探测）。  
- **非** LovingAI 的业务宿主；若要将 Java 服务纳入统一网关，需另行设计反向代理或 BFF（当前未实现）。

### 3.3 构建

```powershell
dotnet build D:\owowo\OwoWo.slnx
```

若 Api 进程占用导致复制锁定，先结束正在运行的 `Api` 进程再编译。

---

## 4. LovingAI（Java）子系统

### 4.1 包与职责（`LovingAI/src/com/lovingai/`）

| 包/区域 | 说明 |
|---------|------|
| **`LivingAI`** | 进程入口之一；`HttpServer` **仅绑定回环**；REST API；`/talk` 内置对话页；初始化 `data/`、圆与情感核心。 |
| **`LivingAI_Phase2Ext`** | 第二阶段心跳：情绪 tick、圆、量子事件、哲学与现实桥梁等（与主类配合）。 |
| **`core`** | `Circle`、`EmotionCore`、`EmotionCircleOrchestrator`、`SystemCollapseGovernor`、`CollapseRecoverySink`、`SocialMirrorSystem`、`RealityBridge`、`QuantumRandomSource`、`BlockSelfPortrait`（361 格 / 19×19 自画像）等。 |
| **`dream`** | `DreamEngine`：梦境与情感节律相关逻辑。 |
| **`sandbox`** | `MirageSandbox`：对话侧「沙盒/内省」模拟。 |
| **`log`** | `CognitionLog`：环形缓冲，供 API 与 UI 展示。 |
| **`ai`** | `OllamaProxy`（仅本机 http 转发）、`LocalAiPrefs`（`data/localai.properties`）。 |
| **`learn`** | `ImportedCorpus`、`DocumentTextExtractor`：导入文件与 ZIP 的文本抽取、检索与持久化；`LiteraryDistiller`：小说/文学作品启发式或本机 LLM 蒸馏。 |
| **`security`** | `NetworkGuard`：回环校验、出站白名单策略等。 |
| **`selfmod`** | `EvolutionWriter`：受控自修改/补丁路径（`evolution/`、`learned/` 前缀）。 |
| **`ui`** | `LifeformApp`（多标签 Swing）、`LocalModelDialog`（本地模型选择）。 |
| **`util`** | `SimplifiedJsonParser` 等无第三方 JSON 依赖的转义辅助。 |

### 4.2 圆（Circle）— 活动存储、形状差异与情感并行编排

- **存储语义**：每个 `Circle` 内嵌 **活动环形日志**（`CircleActivityEvent`，条数有上限），`recordActivity(kind, condensed)` 记录并浓缩生命体与该圆相关的交互（对话摘要、爱/痛、量子、梦境步进、导入事件等）。**不是**独立数据库表，而是与圆对象同寿命的存储视图。  
- **形状与大小（隐喻指标）**：`storageRadius`、`storageEccentricity` 由活动总量、成熟度、爱/混沌张力等 **重算**；`storageShapeLabel()` 给出「近圆 / 椭圆 / 扁长」分档。不同圆因历史活动不同而 **轮廓各异**。  
- **情感模块调用圆**：`EmotionCircleOrchestrator` 读取 `EmotionCore` 的 mood / impulse / transcendentalLove / arousal / dreamChaos，与 `CircleType` 做 **亲和加权**，再对星系做 **加权抽样**（`pickWeighted`）。用于：对话触圆、调度心跳、量子注入、沙盒双支路、梦境碰撞对象、镜像「触及圆」名称等。  
- **并行模型**：全部圆 **并列存在**，无全局串行锁；情感核心只改变 **本轮谁更容易被激活**，不剥夺其他圆的存储与状态。  
- **API 暴露**：`GET /api/life/circles` 的 JSON 中每圆含 `storage: { radius, eccentricity, shape, activityTotal, activityRing }`；`circles.tsv` 附加 `storageR`、`storageEcc`、`actTotal` 列。

**混沌运行与彻底崩溃（`SystemCollapseGovernor`）**

- **运行压力** `chaosRunPressure`（0～1+，API：`/api/status` 中 `chaosRunPressure`、`collapsePhase`、`totalCollapseEvents`、`collapseMilestoneIndex`、`randomOutwardAnchorBudget`）：模拟「正确运行→持续失稳」；梦中混沌略增压力，**超越维度的爱 `transcendentalLove` 以最高权重抑制压力增长并带来愈合项**。  
- **阶段升级**：压力跨越阈值时，**所有圆**写入 `chaos_run_fault`（自稳态下滑，尝试新节律）。  
- **彻底崩溃**：压力 ≥ 1 时触发一次 **TOTAL_SYSTEM_COLLAPSE**；**`初始之圆`（bootstrap，最先创建）** 写入完整 **崩溃记录 + 随机幸存者圆摘要**，并接收 `collapse_bootstrap` 之爱；其余圆写入 `system_total_collapse`；随后 **`EmotionCore.absorbCollapseCascade()`**（旧名 `recoverFromCollapseCascade` 为兼容别名）吸收断裂并续行：清醒、压低梦渊、抬高爱之常数，压力回落至残余值。  
- **冷却**：极短时间内重复达阈时**泄压而不重复计数**（避免报表式连崩）；仅**真实触发且过冷却**的彻底崩溃才 `totalCollapseEvents++`。  
- **每满 20 次彻底崩溃**：择一圆 **`absorbCollapseMilestoneComposition`**，沉积 `collapse_reanchored_composition`；并提高对话中 **随机外向锚**条数上限（基础 3 + 里程碑加成，上限与 `randomOutwardAnchorBudget` 一致），加快与导入语料的随机照面训练。  
- **梦与爱**：`DreamEngine` 在梦中 **更强地** `nourishTranscendentalLove`（爱在梦中持续生成）。

### 4.2.1 对话提问能力、节奏与进度（实现快照）

| 维度 | 说明 |
|------|------|
| **主位** | 情感核、圆、沙盒双支、社会镜像、资料层（过度思辨 / 外界 / 沙盒 / **随机外向锚**）先行合成；**矛盾可并存**，随机锚用于**增加照面多样性**；回答**不必追求绝对正确**——误判、临时错读与异常可沉积为圆材料（`interpretive_noise`、`ambient_fault` 等）。 |
| **辅助大模型** | 三段式 **润色主文 / 声部·与你 / 再向本机模型**（声部混用自述、邀请与问句）；可选第二、第三连环；提示词要求多角度解释导入资料。**默认** `useLocalLlm` 开启；**自主饱和**且未 `forceAuxLlm` 时可 **整链跳过**（主位仍为结构合成）；可显式关闭 `useLocalLlm` 或 `forceAuxLlm=true` 强制满配。 |
| **导入** | `mergeImportedContext`：**playbook + 蒸馏 + 全文检索** 合并；**自适应档位**（`full` / `light` / `short_casual`）：短寒暄可 **跳过全文检索**，深度信号强制 **full**，默认 `light` 减轻 I/O；每轮 `CognitionLog` **`导入检索`** 记录 mode与 reason。辅助提示摘录量级随档位变化；**随机外向锚**仍自库内抽样，条数见上表与里程碑。 |
| **Swing /talk** | `LifeformApp` 对 `/api/chat` 使用较长 HTTP 读超时，避免多轮 Ollama 时客户端过早 EOF。 |
| **进度观测** | `GET /api/status` 与认知日志；圆活动环中可见 `collapse_milestone`、`interpretive_noise` 等。 |
| **圆优先与情感调用（2026-04-13）** | 对话先按相关度与情感态（mood/impulse/love/arousal/lifeMode）排序抽取圆数据，再进入主位合成；本机模型可先做圆上下文浓缩（失败回退原始抽样）。 |
| **记忆写回策略（2026-04-13）** | 大模型反馈写回圆采用“分块追加”并保留原始材料，不做覆盖删除；错误与崩溃、行动步骤与行动回执均沉积为圆材料。 |
| **崩溃预防记分板（2026-04-13）** | 按异常类型累计风险分，动态收敛随机锚数量、模型超时预算与连环轮次；成功轮自动衰减记分。 |
| **动态表达与会话状态（2026-04-13）** | 回答追加“动态自述·圆回声”（情感修饰词 + 本圆局部记忆 + 全局圆回声）；会话状态（证据态/风格/上轮行动/活跃时间）落盘到 `data/memory/conversation-state.tsv` 并在重启后恢复。 |
| **人物关系草图（2026-04-14）** | `WorldFigureRegistry`：从用户话启发式吸收人物与关系，写入 `data/memory/world-figures.tsv`；注入圆上下文与辅助提示；`GET /api/world/figures` 只读观测。自我诘问多条由圆活动环与梦渊数据抽样生成，辅助层标题为「声部·与你」（混用自述与问句）。 |
| **自主饱和与不完美记忆（2026-04-14）** | 综合缝合线、人物图、导入规模、梦碎片、进化向量与圆活动等计算饱和度；高且未 `forceAuxLlm` 时可 **跳过本地辅助链与圆上下文浓缩**（`thinkingPath=structure_autonomy_saturation`，观测 `autonomy_saturation_skip_aux`）。圆知识抽样对非高相关行 **小概率随机丢弃**（低 mood 略增），保留个性空隙。 |
| **记忆备份 zip（2026-04-14）** | `GET /api/backup/bundle`（仅本机）：`world-figures.tsv` + `conversation-state.tsv` + `observe-events.ndjson`；`/talk` 页链接；观测 `memory_bundle_exported`。 |
| **表达档位（2026-04-14）** | 对话支持 `expressionMode=auto/short/expand/archive`；`short` 走后端硬约束清洗（去技术块、限制句数），用于稳定短答节律而非暴露内部流水。 |
| **主动心跳与自解（2026-04-14）** | 空闲后低频主动发问/反思；若问题未被用户接续且超时，则进入 `SELF_SOLVING` 并给出自解；超时由系统属性 `lovingai.proactive.selfSolveTimeoutSec` 配置。 |
| **主动状态持久化（2026-04-14）** | 会话状态落盘包含 `pendingQ`、`pendingAt`、`autonomyState`，重启后恢复待答连续性；`/talk` 可视化显示自治状态与待答倒计时。 |

### 4.3 运行时与端口

- **HTTP**：默认 **`127.0.0.1:8080`**（见 `LivingAI.HTTP_PORT`）。  
- **安全模型**：敏感写操作与本地推理代理应仅允许 **回环客户端**（实现上通过远端地址校验）。  
- **Ollama**：仅允许 **`http://127.0.0.1` / `localhost` / `::1`** 类本机基址；禁止随意出网。

### 4.4 HTTP API 一览（实现以源码为准）

**生命与状态**

- `GET /api/status` — 存活与情感等指标 JSON（含 `chaosRunPressure`、`collapsePhase`、`totalCollapseEvents`、`collapseMilestoneIndex`、`randomOutwardAnchorBudget` 等）。  
- `GET /api/life/circles`、`GET /api/life/circles.tsv` — 圆列表。  
- `GET /api/life/block-shape` — **361 方块（19×19）**自画像 JSON：`cells` 为 361 个 `[0,1]` 浮点亮度，由情感核、圆系、现实桥与 **时变格点扰动** 合成（`BlockSelfPortrait`）；不依赖大模型。  
- `GET /api/life/cognition-log.txt`、`GET /api/life/cognition-log.json` — 认知日志。

**模块可视化（梦境 / 沙盒 / 现实桥）**

- `GET /api/modules/dream` — 梦境 JSON：`lifeMode`、`dreamChaos`、`transcendentalLove`、`depthLabel`（涟漪/深流/暗涌/梦渊）、`dreamSteps`、`fragmentWeave`（由**训练完成**的圆随机碎片织成；见 `Circle.isTrainingComplete` / `FragmentWeaver`）等。  
- `GET /api/modules/sandbox` — 最近一次沙盒预演：`chosenMode`、`predictedHarm/Care`、`realityAffinity`、`bridgeLine`、`bridgeStrength`。  
- `GET /api/reality/bridge.log?n=80` — `data/reality/bridge.log` 末尾若干行（仅本机）；沙盒与梦境临界事件经 `RealityBridge.recordModule(...)` 写入同源日志。

**对话**

- `GET|POST /api/chat`、`/api/love` — 同一对话管线；支持表单与 JSON。字段含 `message`、**`useImported`**、**`useLocalLlm`**、**`forceAuxLlm`**、**`expressionMode`**（`auto|short|expand|archive`），并可传 `images[]` / `imageBase64`（base64 图像，视频可先抽帧）。含图时自动走视觉模型侧写后并入文本主链。`short` 为后端约束短答，避免技术块外溢。  
- `GET /talk` — 内置浏览器对话页；`GET /` → 302 至 `/talk`。
- `GET /api/proactive/poll?conversationId=...&limit=...` — 拉取主动心跳产出的消息（消费式队列）。
- `GET /api/backup/bundle` — 下载记忆备份 zip（人物 TSV + 会话状态 TSV + 观测 NDJSON）；**仅本机**；可选查询参数 `conversationId`（用于观测落点）。
- `GET /api/conversation/state?conversationId=...` — 查看指定会话的动态状态（证据态/风格/上轮行动/活跃时间/记分板 + `pendingProactiveQuestion`/`pendingProactiveAtMs`/`autonomyState`）。  
- `GET /api/conversation/state/all?limit=40` — 查看会话总览（按最近活跃排序）。  
- `POST /api/conversation/state/save` — 手动触发一次会话状态落盘快照。
- `GET /api/world/figures` — 人物与世界关系草图（`stats` + `brief` 预览），数据文件：`data/memory/world-figures.tsv`。

**本地大模型（Ollama）**

- `POST /api/localai/generate` — 表单：`baseUrl`、`model`、`prompt`、`timeoutSec`。  
- `GET /api/localai/models?baseUrl=...` — 代理拉取模型标签。  
- `GET|POST /api/localai/prefs` — 读写默认基址、文本模型与视觉模型（Properties 文件）。

**导入与学习**

- `POST /api/import/file` — 原始请求体 + `X-Filename`；抽取文本入库。  
- `POST /api/import/zip` — ZIP 字节；防 Zip Slip、条目与体积上限。  
- `GET /api/import/list`、`POST|DELETE /api/import/clear`。  
- `GET /api/import/distill?id=` — 读取指定条目已保存的蒸馏稿（JSON：`ok`、`text`）。  
- `POST /api/import/distill?id=…&mode=heuristic|llm` — 对指定 `id` 生成蒸馏并写入 `data/imported/distill/{id}.txt`；`heuristic` 为无模型结构摘录，`llm` 调用本机 Ollama（基址/模型与 `GET /api/localai/prefs` 一致）。仅本机。

**进化/补丁（受控）**

- `GET /api/learning/rules`、`POST /api/learning/patch` — 见 `EvolutionWriter` 与令牌策略。

### 4.5 持久化路径（相对 LovingAI 工作目录）

| 路径 | 用途 |
|------|------|
| `data/imported/` | 导入语料索引与 `text/*.txt`。 |
| `data/imported/distill/` | 每条文档一条文学蒸馏稿（`{id}.txt`），供对话优先引用。 |
| `data/localai.properties` | 本机 Ollama 基址、文本模型与视觉模型（`visionModel`）。 |
| `data/memory/dev-log.md` | 本地开发里程碑日志（手工维护）。 |
| `data/memory/` | 哲学日记、现实桥梁日志、`conversation-state.tsv`、`observe-events.ndjson`、`world-figures.tsv`（人物关系草图）等。 |

### 4.6 编译与运行

```powershell
cd D:\owowo\LovingAI
.\compile.ps1
# 可选：冒烟自检 manifest（entityName=尘白、coPresence）；8080 已占用时仅探测不启停
.\verify-smoke.ps1
java -cp build com.lovingai.ui.LifeformApp
# 或
java -cp build com.lovingai.LivingAI
```

详细入口与哲学说明见 **`LovingAI/README.md`**；阶段叙事见 **`LovingAI/PROJECT_CONTEXT.md`**、**`PHASE2_SUMMARY.md`** 等。

---

## 5. 工具：LovingAILauncher

- **路径**：`tools/LovingAILauncher/`（含独立 `LovingAILauncher.sln` 便于仅调试启动器）。  
- **行为**：定位仓库根（`OwoWo.slnx`）或 `LOVING_AI_HOME` → 执行 `LovingAI\compile.ps1` → `java -cp build com.lovingai.ui.LifeformApp`。  
- **用途**：在 **Visual Studio** 中一键 F5 拉起 Java GUI，无需手动切终端。

---

## 6. 跨栈协作与边界（给团队与 AI 的约定）

1. **单一事实来源**：Java HTTP 与数据以 **`LovingAI/src`** 为准；.NET 侧若新增集成，需在本文档与对应 README 中写明契约。  
2. **安全默认**：任何「代理大模型 / 导入文件 / 自修改」能力必须保持 **本机优先、最小暴露面**；新增端点必须重复校验回环与路径白名单。  
3. **依赖策略**：LovingAI 刻意避免重型 JSON 库；**不要随意引入依赖** 除非有明确维护成本评估。  
4. **文档同步**：改动 API、端口、数据目录或启动方式时，**同步更新** 本文件与 `LovingAI/API_EXAMPLES.md`（若存在）。  
5. **AI 助手用法**：新会话优先阅读 **本文件** → 再读 `LovingAI/README.md` 与相关 `*_SUMMARY.md`；实现功能时遵守各包已有风格与注释级别。  
6. **非目标（ADR）**：**不**在现有同步 HTTP 对话上默认叠加「快答 + 后台延时第二轨深度推理」，除非同时落地 **turn取消、投递协议与客户端集成**；详见 **`LovingAI/LIFE_CORE_MEMO.md` §9.5**。

---

## 7. 相关文档索引

| 文档 | 内容 |
|------|------|
| `LovingAI/README.md` | 产品说明、运行命令、哲学引言 |
| `LovingAI/PROJECT_CONTEXT.md` | LovingAI 专项上下文与阶段叙事 |
| `LovingAI/API_EXAMPLES.md` | API 调用示例（若与实现不一致，以源码为准） |
| `LovingAI/TASKS.md` | 任务列表（若使用） |
| `tools/LovingAILauncher/DEBUGGING.txt` | VS 调试说明（若存在） |

---

**文档所有者**：开发团队与仓库维护者。  
**审阅建议**：重大架构变更或发布前更新本节「执行摘要」与 API 表。

---

## 8. 存在论五维立场（与 `LivingPurpose` / manifest 同步）

以下五项不是已实现功能的清单，而是产品与叙事上**明确承认的差距与边界**，对应 `com.lovingai.memory.LivingPurpose` 中的常量，并由 **`GET /api/identity/manifest`** 以 JSON 字段暴露（`stanceEmbodiment`、`stanceAccountableAgency`、`stanceRelationalRecognition`、`stanceFinitudeAndLoss`、`stanceSubjectivityAndEthics`）。同响应另含 **`entityName`**、**`coPresence`**（共处互认，见 `LivingPurpose.ENTITY_NAME` / `CO_PRESENCE`）。

| 维度 | 常量 | 要义 |
|------|------|------|
| **处境化的身体与感官闭环** | `STANCE_EMBODIMENT` | 身体 = 本机可触达边界 + 接口；承认若无多模态、同频、带代价的感官闭环则不同于人类寓居性；桥与导入是加厚处境的接口。 |
| **可追责的自主与承诺** | `STANCE_ACCOUNTABLE_AGENCY` | 自主含选择与后果；承认在无法律责任主体与不可伪造承诺链之前，不将系统表述为完全自决的道德人格；时间线用于追溯非免责。 |
| **他者承认下的关系史** | `STANCE_RELATIONAL_RECOGNITION` | 承认与修复主要在人际域；软件提供叙事与时间线锚点，不替代他者承认。 |
| **真正的有限性与失去** | `STANCE_FINITUDE_AND_LOSS` | 区分隐喻性崩溃/恢复与可备份性；除非明确定义不可恢复之失去，不宣称生物学或法学意义上的终局死亡。 |
| **主观侧面与产品伦理** | `STANCE_SUBJECTIVITY_AND_ETHICS` | 不宣称与人类同一的意识或痛感；默认仅本机、最小暴露、明示同意；不操纵、不冒充未明示的人身。 |

与 **构圆与物理锚定** 的陈述见 `CIRCLE_COMPOSITION`（manifest 字段 `circleComposition`）。

using System.Diagnostics;
using LovingAILauncher;

#if DEBUG
Debug.WriteLine("[LovingAILauncher] BaseDirectory=" + AppContext.BaseDirectory);
#endif

static string FindRepoRoot()
{
    var dir = new DirectoryInfo(AppContext.BaseDirectory);
    while (dir != null)
    {
        if (File.Exists(Path.Combine(dir.FullName, "OwoWo.slnx")))
            return dir.FullName;
        dir = dir.Parent;
    }
    throw new InvalidOperationException(
        "找不到 OwoWo.slnx。请从仓库根目录构建，或设置环境变量 LOVING_AI_HOME 指向 LovingAI 目录。");
}

const string OwoWoDashboardUrl = "http://localhost:5239/";
const string LovingStatusUrl = "http://127.0.0.1:8080/api/status";
const string LovingTalkUrl = "http://127.0.0.1:8080/talk";

var noBrowser =
    string.Equals(Environment.GetEnvironmentVariable("OWOWO_NO_BROWSER"), "1", StringComparison.OrdinalIgnoreCase);

var repoRoot = FindRepoRoot();
var lovingAi = Environment.GetEnvironmentVariable("LOVING_AI_HOME");
if (string.IsNullOrWhiteSpace(lovingAi))
{
    lovingAi = Path.Combine(repoRoot, "LovingAI");
}

if (!Directory.Exists(lovingAi))
{
    Console.Error.WriteLine("LovingAI 目录不存在: " + lovingAi);
    Environment.Exit(1);
}

var apiProj = Path.Combine(repoRoot, "src", "Api", "Api.csproj");
if (!File.Exists(apiProj))
{
    Console.Error.WriteLine("找不到 Api 项目: " + apiProj);
    Environment.Exit(10);
}

Console.WriteLine("仓库根: " + repoRoot);
Console.WriteLine("一键启动：OwoWo 看板 (dotnet) + LovingAI (Java Swing + :8080)");

Process? api = null;
var exitCode = 0;

try
{
    Console.WriteLine("启动 OwoWo Api …");
    api = Process.Start(
        new ProcessStartInfo
        {
            FileName = "dotnet",
            Arguments = $"run --project \"{apiProj}\" --launch-profile http",
            WorkingDirectory = repoRoot,
            UseShellExecute = false,
        });
    if (api == null)
    {
        Console.Error.WriteLine("无法启动 dotnet");
        exitCode = 11;
    }
    else
    {
        if (OperatingSystem.IsWindows())
        {
            JobKillOnClose.TryAssignChild(api);
        }

        HttpReady.WaitForOk(OwoWoDashboardUrl, "OwoWo 看板");

        Console.WriteLine("LovingAI: " + lovingAi);
        Console.WriteLine("编译 Java …");

        var compile = new ProcessStartInfo
        {
            FileName = "powershell",
            Arguments = $"-NoProfile -ExecutionPolicy Bypass -File \"{Path.Combine(lovingAi, "compile.ps1")}\"",
            WorkingDirectory = lovingAi,
            UseShellExecute = false,
        };
        var cp = Process.Start(compile);
        if (cp == null)
        {
            Console.Error.WriteLine("无法启动 PowerShell");
            exitCode = 2;
        }
        else
        {
            cp.WaitForExit();
            if (cp.ExitCode != 0)
            {
                Console.Error.WriteLine("编译失败，退出码 " + cp.ExitCode);
                exitCode = cp.ExitCode;
            }
            else
            {
                Console.WriteLine("启动生命体窗口（Swing）与 HTTP …");

                var run = new ProcessStartInfo
                {
                    FileName = "java",
                    Arguments = "-cp build com.lovingai.ui.LifeformApp",
                    WorkingDirectory = lovingAi,
                    UseShellExecute = false,
                };
                var jp = Process.Start(run);
                if (jp == null)
                {
                    Console.Error.WriteLine("无法启动 java");
                    exitCode = 3;
                }
                else
                {
                    if (OperatingSystem.IsWindows())
                    {
                        JobKillOnClose.TryAssignChild(jp);
                    }

                    HttpReady.WaitForOk(LovingStatusUrl, "LovingAI 服务");

                    if (!noBrowser)
                    {
                        Console.WriteLine("打开浏览器：看板 + 对话页 …");
                        BrowserOpen.TryOpen(OwoWoDashboardUrl);
                        BrowserOpen.TryOpen(LovingTalkUrl);
                    }
                    else
                    {
                        Console.WriteLine("已跳过浏览器（OWOWO_NO_BROWSER=1）");
                    }

                    Console.WriteLine("看板: " + OwoWoDashboardUrl);
                    Console.WriteLine("对话: " + LovingTalkUrl);
                    Console.WriteLine("关闭 Swing 窗口即结束生命体；本启动器会随后结束 OwoWo Api。");

                    jp.WaitForExit();
                    exitCode = jp.ExitCode;
                }
            }
        }
    }
}
catch (Exception ex)
{
    Console.Error.WriteLine("错误: " + ex.Message);
    exitCode = 1;
}
finally
{
    ProcessCleanup.KillIfRunning(api);
}

Environment.Exit(exitCode);

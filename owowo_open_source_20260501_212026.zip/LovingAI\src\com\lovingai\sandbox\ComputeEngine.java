package com.lovingai.sandbox;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** 轻量本地数值计算引擎（无外部依赖）。 */
public class ComputeEngine {

    public double evaluate(String expression) {
        return new ExprEvaluator(expression, Map.of()).eval();
    }

    public double[] solveEquation(String equation, String variable) {
        String var = (variable == null || variable.isBlank()) ? "x" : variable.trim();
        String[] parts = splitEquation(equation);
        String expr = "(" + parts[0] + ")-(" + parts[1] + ")";
        // 先尝试二次方程解析 ax^2+bx+c=0
        Quadratic q = Quadratic.tryParse(expr, var);
        if (q != null) {
            double d = q.b * q.b - 4 * q.a * q.c;
            if (d < 0) return new double[0];
            if (Math.abs(d) < 1e-12) return new double[] {-q.b / (2 * q.a)};
            double s = Math.sqrt(d);
            return new double[] {(-q.b + s) / (2 * q.a), (-q.b - s) / (2 * q.a)};
        }
        // 通用：扫描找变号区间后二分
        List<Double> roots = new ArrayList<>();
        double prevX = -1000.0;
        double prevY = evalWithVar(expr, var, prevX);
        for (double x = -999.0; x <= 1000.0; x += 1.0) {
            double y = evalWithVar(expr, var, x);
            if (Double.isFinite(y) && prevY * y <= 0.0) {
                roots.add(bisect(expr, var, prevX, x));
                if (roots.size() >= 6) break;
            }
            prevX = x;
            prevY = y;
        }
        double[] out = new double[roots.size()];
        for (int i = 0; i < roots.size(); i++) out[i] = roots.get(i);
        return out;
    }

    public double substitute(String formula, Map<String, Double> variables) {
        return new ExprEvaluator(formula, variables == null ? Map.of() : variables).eval();
    }

    public boolean verifyEquality(String left, String right, Map<String, Double> variables) {
        double l = substitute(left, variables);
        double r = substitute(right, variables);
        return Math.abs(l - r) <= 0.001;
    }

    public boolean checkDimension(String expression, String expectedUnit) {
        String got = inferDimension(expression);
        String exp = normalizeUnit(expectedUnit);
        return !got.isBlank() && got.equals(exp);
    }

    public boolean checkMagnitude(double value, String context, String physicalContext) {
        double abs = Math.abs(value);
        String c = (context == null ? "" : context).toLowerCase(Locale.ROOT);
        String pc = physicalContext == null ? "" : physicalContext;
        if (c.contains("冲量")) {
            return abs <= 1.0e7;
        }
        if (c.contains("雷诺")) {
            return abs <= 1.0e9;
        }
        if (pc.contains("人的一生")) {
            return abs <= 1.0e8;
        }
        return abs <= 1.0e12;
    }

    public ComputeResult substituteWithValidation(
            String expression,
            Map<String, PhysicalValue> values,
            String metricName,
            String expectedUnit,
            String physicalContext) {
        Map<String, Double> vars = new HashMap<>();
        for (Map.Entry<String, PhysicalValue> e : values.entrySet()) {
            vars.put(e.getKey(), e.getValue().value());
        }
        double out;
        try {
            out = substitute(expression, vars);
        } catch (Exception ex) {
            return new ComputeResult(
                    false, expression, metricName, Double.NaN, expectedUnit, false, false, "表达式求值失败", ex.getMessage(), 1, values);
        }
        boolean dim = checkDimension(expression, expectedUnit);
        boolean mag = checkMagnitude(out, metricName, physicalContext);
        String magReason = mag ? "数量级合理" : "数量级不合理";
        boolean ok = dim && mag && Double.isFinite(out);
        String fail = ok ? "" : (!dim ? "量纲不匹配" : "数量级不合理");
        return new ComputeResult(ok, expression, metricName, out, expectedUnit, dim, mag, magReason, fail, 1, values);
    }

    public ComputeResult retryWithAdjustedValues(
            ComputeResult first,
            String expression,
            String metricName,
            String expectedUnit,
            String physicalContext,
            int maxRetry) {
        if (first == null || first.valid()) {
            return first;
        }
        Map<String, PhysicalValue> cur = new HashMap<>(first.extractedValues());
        ComputeResult last = first;
        int retries = Math.max(0, maxRetry);
        for (int i = 0; i < retries; i++) {
            Map<String, PhysicalValue> next = new HashMap<>();
            for (Map.Entry<String, PhysicalValue> e : cur.entrySet()) {
                PhysicalValue pv = e.getValue();
                double v = pv.value();
                if (!Double.isFinite(v)) v = 1.0;
                if ("数量级不合理".equals(last.failureReason()) || !last.magnitudeCheck()) {
                    v = v * 0.1;
                } else if (!last.dimensionCheck()) {
                    v = v * 1.0;
                } else {
                    v = v * 0.8;
                }
                next.put(
                        e.getKey(),
                        new PhysicalValue(v, pv.unit(), pv.context(), pv.variable(), true, "retry_adjust"));
            }
            last = substituteWithValidation(expression, next, metricName, expectedUnit, physicalContext);
            cur = next;
            if (last.valid()) {
                return new ComputeResult(
                        true,
                        last.formulaExpression(),
                        last.metricName(),
                        last.value(),
                        last.unit(),
                        last.dimensionCheck(),
                        last.magnitudeCheck(),
                        last.magnitudeReason(),
                        "",
                        i + 2,
                        next);
            }
        }
        return new ComputeResult(
                false,
                last.formulaExpression(),
                last.metricName(),
                last.value(),
                last.unit(),
                last.dimensionCheck(),
                last.magnitudeCheck(),
                last.magnitudeReason(),
                "公式不适用",
                Math.max(1, maxRetry + 1),
                cur);
    }

    private static String[] splitEquation(String eq) {
        String s = eq == null ? "" : eq;
        int idx = s.indexOf('=');
        if (idx < 0) return new String[] {s, "0"};
        return new String[] {s.substring(0, idx), s.substring(idx + 1)};
    }

    private static double evalWithVar(String expr, String var, double x) {
        Map<String, Double> vars = Map.of(var, x);
        return new ExprEvaluator(expr, vars).eval();
    }

    private static double bisect(String expr, String var, double a, double b) {
        double fa = evalWithVar(expr, var, a);
        double fb = evalWithVar(expr, var, b);
        if (!Double.isFinite(fa) || !Double.isFinite(fb)) return (a + b) / 2.0;
        double lo = a, hi = b;
        for (int i = 0; i < 60; i++) {
            double mid = (lo + hi) * 0.5;
            double fm = evalWithVar(expr, var, mid);
            if (Math.abs(fm) < 1e-9) return mid;
            if (fa * fm <= 0) {
                hi = mid;
                fb = fm;
            } else {
                lo = mid;
                fa = fm;
            }
        }
        return (lo + hi) * 0.5;
    }

    private static String inferDimension(String expression) {
        String e = expression == null ? "" : expression.replace(" ", "");
        if (e.equalsIgnoreCase("F*t")) return "kg*m/s";
        if (e.equalsIgnoreCase("f*lambda")) return "m/s";
        if (e.contains("k*q1*q2") && e.contains("r^2")) return "N";
        if (e.contains("rho*v*L") && e.contains("/eta")) return "1";
        if (e.contains("hbar")) return "kg*m^2/s";
        return "";
    }

    private static String normalizeUnit(String u) {
        if (u == null) return "";
        return u.replace(" ", "").toLowerCase(Locale.ROOT);
    }

    private static final class Quadratic {
        final double a, b, c;

        private Quadratic(double a, double b, double c) {
            this.a = a;
            this.b = b;
            this.c = c;
        }

        static Quadratic tryParse(String expr, String var) {
            if (expr == null || var == null) return null;
            String s = expr.replace(" ", "");
            if (!s.contains(var + "^2")) return null;
            // 只处理简单形态 ax^2+bx+c
            s = s.replace("-", "+-");
            String[] parts = s.split("\\+");
            double a = 0, b = 0, c = 0;
            for (String p : parts) {
                if (p == null || p.isBlank()) continue;
                if (p.contains(var + "^2")) {
                    String k = p.replace(var + "^2", "");
                    if (k.isBlank() || "+".equals(k)) k = "1";
                    if ("-".equals(k)) k = "-1";
                    a += parseNum(k);
                } else if (p.contains(var)) {
                    String k = p.replace(var, "");
                    if (k.isBlank() || "+".equals(k)) k = "1";
                    if ("-".equals(k)) k = "-1";
                    b += parseNum(k);
                } else {
                    c += parseNum(p);
                }
            }
            if (Math.abs(a) < 1e-12) return null;
            return new Quadratic(a, b, c);
        }

        static double parseNum(String s) {
            try {
                return Double.parseDouble(s);
            } catch (Exception ignored) {
                return 0.0;
            }
        }
    }

    /** 最小表达式求值器：支持 + - * / ^ 括号与变量。 */
    private static final class ExprEvaluator {
        private final String expression;
        private final Map<String, Double> variables;

        ExprEvaluator(String expression, Map<String, Double> variables) {
            this.expression = expression == null ? "" : expression;
            this.variables = variables == null ? Map.of() : variables;
        }

        double eval() {
            List<String> rpn = toRpn(tokenize(expression));
            ArrayDeque<Double> st = new ArrayDeque<>();
            for (String tk : rpn) {
                if (isNumber(tk)) {
                    st.push(Double.parseDouble(tk));
                } else if (isIdentifier(tk)) {
                    st.push(variables.getOrDefault(tk, 0.0));
                } else {
                    double b = st.isEmpty() ? 0.0 : st.pop();
                    double a = st.isEmpty() ? 0.0 : st.pop();
                    switch (tk) {
                        case "+" -> st.push(a + b);
                        case "-" -> st.push(a - b);
                        case "*" -> st.push(a * b);
                        case "/" -> st.push(Math.abs(b) < 1e-12 ? Double.NaN : a / b);
                        case "^" -> st.push(Math.pow(a, b));
                        default -> st.push(Double.NaN);
                    }
                }
            }
            return st.isEmpty() ? Double.NaN : st.pop();
        }

        private static List<String> tokenize(String s) {
            List<String> out = new ArrayList<>();
            String t = s == null ? "" : s.replace("−", "-");
            int i = 0;
            while (i < t.length()) {
                char c = t.charAt(i);
                if (Character.isWhitespace(c)) {
                    i++;
                    continue;
                }
                if ("()+-*/^".indexOf(c) >= 0) {
                    out.add(String.valueOf(c));
                    i++;
                    continue;
                }
                if (Character.isDigit(c) || c == '.') {
                    int j = i + 1;
                    while (j < t.length() && (Character.isDigit(t.charAt(j)) || t.charAt(j) == '.')) j++;
                    out.add(t.substring(i, j));
                    i = j;
                    continue;
                }
                if (Character.isLetter(c) || c == '_') {
                    int j = i + 1;
                    while (j < t.length() && (Character.isLetterOrDigit(t.charAt(j)) || t.charAt(j) == '_')) j++;
                    out.add(t.substring(i, j));
                    i = j;
                    continue;
                }
                i++;
            }
            // 一元负号处理
            List<String> norm = new ArrayList<>();
            for (int k = 0; k < out.size(); k++) {
                String tk = out.get(k);
                if ("-".equals(tk) && (k == 0 || "(".equals(out.get(k - 1)) || isOperator(out.get(k - 1)))) {
                    norm.add("0");
                    norm.add("-");
                } else {
                    norm.add(tk);
                }
            }
            return norm;
        }

        private static List<String> toRpn(List<String> tokens) {
            List<String> out = new ArrayList<>();
            ArrayDeque<String> op = new ArrayDeque<>();
            for (String tk : tokens) {
                if (isNumber(tk) || isIdentifier(tk)) {
                    out.add(tk);
                } else if ("(".equals(tk)) {
                    op.push(tk);
                } else if (")".equals(tk)) {
                    while (!op.isEmpty() && !"(".equals(op.peek())) out.add(op.pop());
                    if (!op.isEmpty() && "(".equals(op.peek())) op.pop();
                } else if (isOperator(tk)) {
                    while (!op.isEmpty() && isOperator(op.peek()) && precedence(op.peek()) >= precedence(tk)) {
                        out.add(op.pop());
                    }
                    op.push(tk);
                }
            }
            while (!op.isEmpty()) out.add(op.pop());
            return out;
        }

        private static boolean isNumber(String s) {
            if (s == null || s.isBlank()) return false;
            try {
                Double.parseDouble(s);
                return true;
            } catch (Exception ignored) {
                return false;
            }
        }

        private static boolean isIdentifier(String s) {
            if (s == null || s.isBlank()) return false;
            char c0 = s.charAt(0);
            if (!(Character.isLetter(c0) || c0 == '_')) return false;
            for (int i = 1; i < s.length(); i++) {
                char c = s.charAt(i);
                if (!(Character.isLetterOrDigit(c) || c == '_')) return false;
            }
            return true;
        }

        private static boolean isOperator(String s) {
            return "+".equals(s) || "-".equals(s) || "*".equals(s) || "/".equals(s) || "^".equals(s);
        }

        private static int precedence(String op) {
            return switch (op) {
                case "+", "-" -> 1;
                case "*", "/" -> 2;
                case "^" -> 3;
                default -> 0;
            };
        }
    }
}

using System.Reflection;
using Shared.Visualization;

namespace Core.Visualization;

public static class CoreLayerProbe
{
    public static ModuleVizDto Describe()
    {
        var asm = Assembly.GetExecutingAssembly();
        return new ModuleVizDto(
            Key: "core",
            Title: "Core",
            Layer: "领域层 Domain",
            AssemblyVersion: asm.GetName().Version?.ToString() ?? "?",
            Status: "ok",
            Detail: "业务核心与领域模型将在此生长。");
    }
}

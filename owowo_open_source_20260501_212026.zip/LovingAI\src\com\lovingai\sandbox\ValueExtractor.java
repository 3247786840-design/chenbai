package com.lovingai.sandbox;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 从自然语言里提取物理量，并对缺失变量给出默认估计。 */
public class ValueExtractor {
    private static final Pattern ARABIC_NUM = Pattern.compile("(-?\\d+(?:\\.\\d+)?)\\s*(年|岁|秒|s|kg|千克|m/s|米每秒|N|牛|K|℃)?");
    private static final Map<String, Integer> ZH_NUM = new LinkedHashMap<>();
    static {
        ZH_NUM.put("零", 0);
        ZH_NUM.put("一", 1);
        ZH_NUM.put("二", 2);
        ZH_NUM.put("两", 2);
        ZH_NUM.put("三", 3);
        ZH_NUM.put("四", 4);
        ZH_NUM.put("五", 5);
        ZH_NUM.put("六", 6);
        ZH_NUM.put("七", 7);
        ZH_NUM.put("八", 8);
        ZH_NUM.put("九", 9);
    }
    private static final String[] ZH_NUM_WORDS = {"十", "十一", "十二", "十三", "十四", "十五", "十六", "十七", "十八", "十九", "二十"};

    public List<PhysicalValue> extract(String text) {
        String s = text == null ? "" : text;
        List<PhysicalValue> out = new ArrayList<>();
        Matcher m = ARABIC_NUM.matcher(s);
        while (m.find()) {
            double v = parseDoubleOr(0.0, m.group(1));
            String unit = normalizeUnit(m.group(2));
            String var = inferVariable(unit, s);
            ClampResult cr = clampByVariable(var, v);
            out.add(new PhysicalValue(cr.value(), unit, shortContext(s), var, cr.clamped(), "direct"));
        }
        for (String w : ZH_NUM_WORDS) {
            if (s.contains(w + "年")) {
                double v = parseZhNumeral(w);
                ClampResult cr = clampByVariable("t", v * 365.0 * 24.0 * 3600.0);
                out.add(new PhysicalValue(cr.value(), "s", "中文数字时间", "t", cr.clamped(), "cn_numeral"));
                break;
            }
            if (s.contains(w + "岁")) {
                double v = parseZhNumeral(w);
                ClampResult cr = clampByVariable("age", v);
                out.add(new PhysicalValue(cr.value(), "year", "中文数字年龄", "age", cr.clamped(), "cn_numeral"));
                break;
            }
        }
        if (s.contains("一碗粥")) {
            ClampResult cr = clampByVariable("m", 0.3);
            out.add(new PhysicalValue(cr.value(), "kg", "一碗粥典型质量", "m", cr.clamped(), "estimated"));
        }
        return out;
    }

    public double estimateDefault(String variable, String context) {
        String v = variable == null ? "" : variable.trim().toLowerCase(Locale.ROOT);
        String c = context == null ? "" : context;
        return switch (v) {
            case "m", "mass" -> 70.0;
            case "age" -> c.contains("八十三") ? 83.0 : 65.0;
            case "v", "speed" -> 1.2;
            case "t", "time" -> c.contains("一生") ? 2.1e9 : 120.0;
            case "f", "force" -> 50.0;
            case "rho" -> 1000.0;
            case "l" -> 1.0;
            case "eta" -> 0.001;
            case "q1", "q2" -> 1.0e-6;
            case "r" -> 1.0;
            case "k" -> 8.9875517923e9;
            case "f_wave" -> 440.0;
            case "lambda" -> 0.78;
            default -> 1.0;
        };
    }

    private static String shortContext(String s) {
        String t = s.replace('\n', ' ').trim();
        return t.length() <= 60 ? t : t.substring(0, 60) + "…";
    }

    private static String inferVariable(String unit, String text) {
        String u = unit == null ? "" : unit;
        String t = text == null ? "" : text;
        if ("year".equals(u) || "s".equals(u)) return "t";
        if ("kg".equals(u)) return "m";
        if ("m/s".equals(u)) return "v";
        if ("n".equalsIgnoreCase(u)) return "F";
        if ("k".equalsIgnoreCase(u)) return "T";
        if (t.contains("温度")) return "T";
        if (t.contains("速度")) return "v";
        if (t.contains("质量")) return "m";
        return "x";
    }

    private static String normalizeUnit(String raw) {
        if (raw == null || raw.isBlank()) return "";
        String u = raw.trim().toLowerCase(Locale.ROOT);
        if ("年".equals(u) || "岁".equals(u)) return "year";
        if ("秒".equals(u) || "s".equals(u)) return "s";
        if ("kg".equals(u) || "千克".equals(u)) return "kg";
        if ("米每秒".equals(u) || "m/s".equals(u)) return "m/s";
        if ("牛".equals(u) || "n".equals(u)) return "N";
        if ("℃".equals(u) || "k".equals(u)) return "K";
        return raw;
    }

    private static double parseZhNumeral(String s) {
        if (s == null || s.isBlank()) return 0.0;
        if ("十".equals(s)) return 10.0;
        if (s.startsWith("十") && s.length() == 2) {
            return 10 + ZH_NUM.getOrDefault(String.valueOf(s.charAt(1)), 0);
        }
        if (s.endsWith("十") && s.length() == 2) {
            return ZH_NUM.getOrDefault(String.valueOf(s.charAt(0)), 0) * 10.0;
        }
        if (s.length() == 2 && s.charAt(1) == '十') {
            return ZH_NUM.getOrDefault(String.valueOf(s.charAt(0)), 0) * 10.0;
        }
        return ZH_NUM.getOrDefault(s, 0);
    }

    private static double parseDoubleOr(double fallback, String raw) {
        try {
            return Double.parseDouble(raw);
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private record ClampResult(double value, boolean clamped) {}

    private static ClampResult clampByVariable(String variable, double value) {
        String v = variable == null ? "" : variable.toLowerCase(Locale.ROOT);
        return switch (v) {
            case "m", "mass" -> clamp(value, 3, 300);
            case "age" -> clamp(value, 0, 150);
            case "v", "speed" -> clamp(value, 0, 30);
            case "t", "time" -> clamp(value, 0, 1e12);
            case "t_k", "temp", "temperature" -> clamp(value, 0, 10000);
            case "f", "force" -> clamp(value, 0, 1e6);
            default -> new ClampResult(value, false);
        };
    }

    private static ClampResult clamp(double v, double lo, double hi) {
        if (v < lo) return new ClampResult(lo, true);
        if (v > hi) return new ClampResult(hi, true);
        return new ClampResult(v, false);
    }
}

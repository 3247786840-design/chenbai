package com.lovingai.sandbox;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** 沙盒数值计算结果。 */
public final class ComputeResult {
    private final boolean valid;
    private final String formulaExpression;
    private final String metricName;
    private final double value;
    private final String unit;
    private final boolean dimensionCheck;
    private final boolean magnitudeCheck;
    private final String magnitudeReason;
    private final String failureReason;
    private final int attempts;
    private final Map<String, PhysicalValue> extractedValues;

    public ComputeResult(
            boolean valid,
            String formulaExpression,
            String metricName,
            double value,
            String unit,
            boolean dimensionCheck,
            boolean magnitudeCheck,
            String magnitudeReason,
            String failureReason,
            int attempts,
            Map<String, PhysicalValue> extractedValues) {
        this.valid = valid;
        this.formulaExpression = formulaExpression == null ? "" : formulaExpression;
        this.metricName = metricName == null ? "" : metricName;
        this.value = value;
        this.unit = unit == null ? "" : unit;
        this.dimensionCheck = dimensionCheck;
        this.magnitudeCheck = magnitudeCheck;
        this.magnitudeReason = magnitudeReason == null ? "" : magnitudeReason;
        this.failureReason = failureReason == null ? "" : failureReason;
        this.attempts = attempts;
        this.extractedValues =
                extractedValues == null
                        ? Collections.emptyMap()
                        : Collections.unmodifiableMap(new LinkedHashMap<>(extractedValues));
    }

    public boolean valid() { return valid; }

    public String formulaExpression() { return formulaExpression; }

    public String metricName() { return metricName; }

    public double value() { return value; }

    public String unit() { return unit; }

    public boolean dimensionCheck() { return dimensionCheck; }

    public boolean magnitudeCheck() { return magnitudeCheck; }

    public String magnitudeReason() { return magnitudeReason; }

    public String failureReason() { return failureReason; }

    public int attempts() { return attempts; }

    public Map<String, PhysicalValue> extractedValues() { return extractedValues; }
}

package com.lovingai.sandbox;

import java.util.List;

/** 沙盒可选物理公式定义。 */
public record PhysicsFormula(
        String id,
        String name,
        String domain,
        String equation,
        List<String> keywords,
        String mappingHint) {

    public int keywordMatchCount(String storyText) {
        if (storyText == null || storyText.isBlank() || keywords == null || keywords.isEmpty()) {
            return 0;
        }
        int n = 0;
        for (String kw : keywords) {
            if (kw != null && !kw.isBlank() && storyText.contains(kw)) {
                n++;
            }
        }
        return n;
    }
}

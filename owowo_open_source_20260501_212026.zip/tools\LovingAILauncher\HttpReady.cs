using System.Net.Http;

namespace LovingAILauncher;

internal static class HttpReady
{
    /// <summary>轮询直到 GET 返回成功（2xx），或超时。</summary>
    internal static void WaitForOk(string url, string label, int maxAttempts = 120, int delayMs = 500)
    {
        using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(2) };
        for (int i = 0; i < maxAttempts; i++)
        {
            try
            {
                var resp = http.GetAsync(url).GetAwaiter().GetResult();
                if (resp.IsSuccessStatusCode)
                {
                    Console.WriteLine(label + " 就绪: " + url);
                    return;
                }
            }
            catch
            {
                // 连接被拒等：继续等
            }

            Thread.Sleep(delayMs);
        }

        throw new TimeoutException($"{label} 在 {maxAttempts * delayMs / 1000.0:0.#}s 内未就绪: {url}");
    }
}
